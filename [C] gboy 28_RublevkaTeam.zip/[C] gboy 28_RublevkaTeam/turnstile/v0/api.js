"use strict";
(function () {
  function Lr(e, t, r, a, i, l, s) {
    try {
      var d = e[l](s), v = d.value;
    } catch (p) {
      r(p);
      return;
    }
    d.done ? t(v) : Promise.resolve(v).then(a, i);
  }
  function Nr(e) {
    return function () {
      var t = this, r = arguments;
      return new Promise(function (a, i) {
        var l = e.apply(t, r);
        function s(v) {
          Lr(l, a, i, s, d, "next", v);
        }
        function d(v) {
          Lr(l, a, i, s, d, "throw", v);
        }
        s(void 0);
      });
    };
  }
  function We(e, t, r) {
    return ((t in e) ? Object.defineProperty(e, t, {
      value: r,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }) : e[t] = r, e);
  }
  function A(e, t) {
    "@swc/helpers - instanceof";
    return t != null && typeof Symbol != "undefined" && t[Symbol.hasInstance] ? !!t[Symbol.hasInstance](e) : e instanceof t;
  }
  function ke(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t] != null ? arguments[t] : {}, a = Object.keys(r);
      (typeof Object.getOwnPropertySymbols == "function" && (a = a.concat(Object.getOwnPropertySymbols(r).filter(function (i) {
        return Object.getOwnPropertyDescriptor(r, i).enumerable;
      }))), a.forEach(function (i) {
        We(e, i, r[i]);
      }));
    }
    return e;
  }
  function va(e, t) {
    var r = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var a = Object.getOwnPropertySymbols(e);
      (t && (a = a.filter(function (i) {
        return Object.getOwnPropertyDescriptor(e, i).enumerable;
      })), r.push.apply(r, a));
    }
    return r;
  }
  function Yt(e, t) {
    return (t = t != null ? t : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : va(Object(t)).forEach(function (r) {
      Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
    }), e);
  }
  function Pr(e) {
    if (Array.isArray(e)) return e;
  }
  function Dr(e, t) {
    var r = e == null ? null : typeof Symbol != "undefined" && e[Symbol.iterator] || e["@@iterator"];
    if (r != null) {
      var a = [], i = !0, l = !1, s, d;
      try {
        for (r = r.call(e); !(i = (s = r.next()).done) && (a.push(s.value), !(t && a.length === t)); i = !0) ;
      } catch (v) {
        (l = !0, d = v);
      } finally {
        try {
          !i && r.return != null && r.return();
        } finally {
          if (l) throw d;
        }
      }
      return a;
    }
  }
  function Fr() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function tt(e, t) {
    (t == null || t > e.length) && (t = e.length);
    for (var r = 0, a = new Array(t); r < t; r++) a[r] = e[r];
    return a;
  }
  function wt(e, t) {
    if (e) {
      if (typeof e == "string") return tt(e, t);
      var r = Object.prototype.toString.call(e).slice(8, -1);
      if ((r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set")) return Array.from(r);
      if (r === "Arguments" || (/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/).test(r)) return tt(e, t);
    }
  }
  function Ve(e, t) {
    return Pr(e) || Dr(e, t) || wt(e, t) || Fr();
  }
  function Ur(e) {
    if (Array.isArray(e)) return tt(e);
  }
  function Hr(e) {
    if (typeof Symbol != "undefined" && e[Symbol.iterator] != null || e["@@iterator"] != null) return Array.from(e);
  }
  function Wr() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function Ce(e) {
    return Ur(e) || Hr(e) || wt(e) || Wr();
  }
  function D(e) {
    "@swc/helpers - typeof";
    return e && typeof Symbol != "undefined" && e.constructor === Symbol ? "symbol" : typeof e;
  }
  function Vr(e, t) {
    var r, a, i, l = {
      label: 0,
      sent: function () {
        if (i[0] & 1) throw i[1];
        return i[1];
      },
      trys: [],
      ops: []
    }, s = Object.create((typeof Iterator == "function" ? Iterator : Object).prototype), d = Object.defineProperty;
    return (d(s, "next", {
      value: v(0)
    }), d(s, "throw", {
      value: v(1)
    }), d(s, "return", {
      value: v(2)
    }), typeof Symbol == "function" && d(s, Symbol.iterator, {
      value: function () {
        return this;
      }
    }), s);
    function v(g) {
      return function (w) {
        return p([g, w]);
      };
    }
    function p(g) {
      if (r) throw new TypeError("Generator is already executing.");
      for (; (s && (s = 0, g[0] && (l = 0)), l); ) try {
        if ((r = 1, a && (i = g[0] & 2 ? a.return : g[0] ? a.throw || ((i = a.return) && i.call(a), 0) : a.next) && !(i = i.call(a, g[1])).done)) return i;
        switch ((a = 0, i && (g = [g[0] & 2, i.value]), g[0])) {
          case 0:
          case 1:
            i = g;
            break;
          case 4:
            return (l.label++, {
              value: g[1],
              done: !1
            });
          case 5:
            (l.label++, a = g[1], g = [0]);
            continue;
          case 7:
            (g = l.ops.pop(), l.trys.pop());
            continue;
          default:
            if ((i = l.trys, !(i = i.length > 0 && i[i.length - 1]) && (g[0] === 6 || g[0] === 2))) {
              l = 0;
              continue;
            }
            if (g[0] === 3 && (!i || g[1] > i[0] && g[1] < i[3])) {
              l.label = g[1];
              break;
            }
            if (g[0] === 6 && l.label < i[1]) {
              (l.label = i[1], i = g);
              break;
            }
            if (i && l.label < i[2]) {
              (l.label = i[2], l.ops.push(g));
              break;
            }
            (i[2] && l.ops.pop(), l.trys.pop());
            continue;
        }
        g = t.call(e, l);
      } catch (w) {
        (g = [6, w], a = 0);
      } finally {
        r = i = 0;
      }
      if (g[0] & 5) throw g[1];
      return {
        value: g[0] ? g[1] : void 0,
        done: !0
      };
    }
  }
  var Rt = "cf-chl-widget-", J = "cloudflare-challenge", qr = ".cf-turnstile", Br = ".cf-challenge", Jr = ".g-recaptcha", zr = "cf-turnstile-response", jr = "g-recaptcha-response", qe = 30000, rt = 180 * 1000, Kr = 10000, Gr = 8000, Xr = 3600 * 1000, Qt = "private-token", Yr = 3, Qr = 500, $r = 500, me = "", $t = "_cftscs_", Zr = 512;
  var ge = (function (e) {
    return (e.Managed = "managed", e.NonInteractive = "non-interactive", e.Invisible = "invisible", e);
  })({}), Z = (function (e) {
    return (e.Normal = "normal", e.Compact = "compact", e.Invisible = "invisible", e.Flexible = "flexible", e);
  })({}), St = (function (e) {
    return (e.Auto = "auto", e.Light = "light", e.Dark = "dark", e);
  })({}), It = (function (e) {
    return (e.Verifying = "verifying", e.VerifyingHavingTroubles = "verifying-having-troubles", e.VerifyingOverrun = "verifying-overrun", e.FailureWoHavingTroubles = "failure-wo-having-troubles", e.FailureHavingTroubles = "failure-having-troubles", e.FailureFeedback = "failure-feedback", e.FailureFeedbackCode = "failure-feedback-code", e.ExpiredNeverRefresh = "expired-never-refresh", e.ExpiredManualRefresh = "expired-manual-refresh", e.TimeoutNeverRefresh = "timeout-never-refresh", e.TimeoutManualRefresh = "timeout-manual-refresh", e.InteractivityRequired = "interactivity-required", e.UnsupportedBrowser = "unsupported-browser", e.TimeCheckCachedWarning = "time-check-cached-warning", e.InvalidDomain = "invalid-domain", e);
  })({}), At = (function (e) {
    return (e.Never = "never", e.Auto = "auto", e);
  })({}), Be = (function (e) {
    return (e.Never = "never", e.Manual = "manual", e.Auto = "auto", e);
  })({}), nt = (function (e) {
    return (e.Never = "never", e.Manual = "manual", e.Auto = "auto", e);
  })({}), _e = (function (e) {
    return (e.Always = "always", e.Execute = "execute", e.InteractionOnly = "interaction-only", e);
  })({}), at = (function (e) {
    return (e.Render = "render", e.Execute = "execute", e);
  })({}), it = (function (e) {
    return (e.Execute = "execute", e);
  })({}), ee = (function (e) {
    return (e.New = "new", e.CrashedRetry = "crashed_retry", e.FailureRetry = "failure_retry", e.StaleExecute = "stale_execute", e.AutoExpire = "auto_expire", e.AutoTimeout = "auto_timeout", e.ManualRefresh = "manual_refresh", e.Api = "api", e.CheckDelays = "check_delays", e.UpgradeReload = "upgrade_reload", e.TimeCheckCachedWarningAux = "time_check_cached_warning_aux", e.JsCookiesMissingAux = "js_cookies_missing_aux", e.RedirectingTextOverrun = "redirecting_text_overrun", e);
  })({});
  var Zt = function (t) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 3;
    return t.length > r ? t.slice(0, r) : t;
  };
  function en(e) {
    if (!e) return "-";
    var t = function (a, i) {
      if (!a || a.tagName === "BODY") return i;
      for (var l = 1, s = a.previousElementSibling; s; ) (s.tagName === a.tagName && l++, s = s.previousElementSibling);
      var d = Zt(a.tagName.toLowerCase()), v = ("").concat(d, "[").concat(l, "]");
      return t(a.parentElement, ("/").concat(v).concat(i));
    };
    return t(e, "");
  }
  function tn(e) {
    if (!e) return "";
    var t = e.getBoundingClientRect();
    return ("").concat(t.top, "|").concat(t.right);
  }
  var ma = {
    button: "b",
    checkbox: "c",
    email: "e",
    hidden: "h",
    number: "n",
    password: "p",
    radio: "r",
    select: "sl",
    submit: "s",
    text: "t",
    textarea: "ta"
  };
  function rn(e) {
    var t;
    if (!e) return "";
    var r = e.closest("form");
    if (!r) return "nf";
    var a = r.querySelectorAll("input, select, textarea, button"), i = Ce(a).slice(0, 20).map(function (s) {
      var d;
      return (d = ma[s.type]) !== null && d !== void 0 ? d : "-";
    }).join(""), l = [("m:").concat((t = r.getAttribute("method")) !== null && t !== void 0 ? t : ""), ("f:").concat(a.length), i].join("|");
    return l;
  }
  function ga(e) {
    return A(e, Element) ? e : e.parentElement;
  }
  function _a(e) {
    return ("querySelectorAll" in e);
  }
  function nn(e, t) {
    var r, a = t == null ? void 0 : t.shouldIgnoreElement;
    if (a !== void 0) {
      var i = A(e, Element) ? [e] : [];
      (r = i).push.apply(r, Ce(e.querySelectorAll("*")));
      var l = new Set(), s, d = !0, v = !1, p = void 0;
      try {
        for (var g = i[Symbol.iterator](), w; !(d = (w = g.next()).done); d = !0) {
          var k = w.value;
          if (s !== void 0) {
            if (s.contains(k)) {
              l.add(k);
              continue;
            }
            s = void 0;
          }
          a(k) && (l.add(k), s = k);
        }
      } catch (H) {
        (v = !0, p = H);
      } finally {
        try {
          !d && g.return != null && g.return();
        } finally {
          if (v) throw p;
        }
      }
      return l;
    }
  }
  function an(e, t) {
    var r = ga(e);
    return r === null || t === void 0 ? !1 : t.has(r);
  }
  function on(e, t) {
    var r = nn(e, t);
    return Ce(e.querySelectorAll("*")).filter(function (a) {
      return !an(a, r);
    }).length;
  }
  function un(e, t, r, a) {
    for (var i = "", l = _a(e) ? nn(e, a) : void 0, s = document.createNodeIterator(e, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT), d = s.nextNode(); d !== null && i.length < r; ) {
      if (!an(d, l)) {
        for (var v = 0, p = d; p !== null && p !== e; ) (v++, p = p.parentNode);
        if (v <= t) if (A(d, Element)) {
          var g = d;
          i += Zt(g.tagName.toLowerCase());
          var w = !0, k = !1, H = void 0;
          try {
            for (var R = g.attributes[Symbol.iterator](), F; !(w = (F = R.next()).done); w = !0) {
              var C = F.value, N;
              (a == null || (N = a.shouldIgnoreAttribute) === null || N === void 0 ? void 0 : N.call(a, g, C)) !== !0 && (i += ("_").concat(Zt(C.name, 2)));
            }
          } catch (I) {
            (k = !0, H = I);
          } finally {
            try {
              !w && R.return != null && R.return();
            } finally {
              if (k) throw H;
            }
          }
          i += ">";
        } else d.nodeType === Node.TEXT_NODE && (i += "-t");
      }
      d = s.nextNode();
    }
    return i.slice(0, r);
  }
  function ln(e) {
    if (typeof e != "string") throw new TypeError(("djb2: expected string, got ").concat(typeof e == "undefined" ? "undefined" : D(e)));
    for (var t = 5381, r = 0; r < e.length; r++) {
      var a = e.charCodeAt(r);
      t = t * 33 ^ a;
    }
    return t >>> 0;
  }
  var cn = 300, dn = 10, sn = 200100, fn = 200500, pn = 300020, Ot = 300030, kt = 300031;
  var vn = (function (e) {
    return (e.Failure = "failure", e.Verifying = "verifying", e.Overrunning = "overrunning", e.Custom = "custom", e.TimeCheckCachedWarning = "timecheckcachedwarning", e.UnsupportedBrowser = "unsupportedbrowser", e.InvalidDomain = "invaliddomain", e);
  })({});
  function Me(e) {
    return (Me = Object.setPrototypeOf ? Object.getPrototypeOf : function (r) {
      return r.__proto__ || Object.getPrototypeOf(r);
    }, Me(e));
  }
  function ot() {
    try {
      var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
    } catch (t) {}
    return (ot = function () {
      return !!e;
    })();
  }
  function mn(e) {
    if (e === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e;
  }
  function gn(e, t) {
    return t && (D(t) === "object" || typeof t == "function") ? t : mn(e);
  }
  function _n(e, t, r) {
    return (t = Me(t), gn(e, ot() ? Reflect.construct(t, r || [], Me(e).constructor) : t.apply(e, r)));
  }
  function yn(e, t) {
    if (!A(e, t)) throw new TypeError("Cannot call a class as a function");
  }
  function Re(e, t) {
    return (Re = Object.setPrototypeOf || (function (a, i) {
      return (a.__proto__ = i, a);
    }), Re(e, t));
  }
  function hn(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Super expression must either be null or a function");
    (e.prototype = Object.create(t && t.prototype, {
      constructor: {
        value: e,
        writable: !0,
        configurable: !0
      }
    }), t && Re(e, t));
  }
  function ut(e, t, r) {
    return (ot() ? ut = Reflect.construct : ut = function (i, l, s) {
      var d = [null];
      d.push.apply(d, l);
      var v = Function.bind.apply(i, d), p = new v();
      return (s && Re(p, s.prototype), p);
    }, ut.apply(null, arguments));
  }
  function bn(e) {
    return Function.toString.call(e).indexOf("[native code]") !== -1;
  }
  function Ct(e) {
    var t = typeof Map == "function" ? new Map() : void 0;
    return (Ct = function (a) {
      if (a === null || !bn(a)) return a;
      if (typeof a != "function") throw new TypeError("Super expression must either be null or a function");
      if (typeof t != "undefined") {
        if (t.has(a)) return t.get(a);
        t.set(a, i);
      }
      function i() {
        return ut(a, arguments, Me(this).constructor);
      }
      return (i.prototype = Object.create(a.prototype, {
        constructor: {
          value: i,
          enumerable: !1,
          writable: !0,
          configurable: !0
        }
      }), Re(i, a));
    }, Ct(e));
  }
  var En = (function (e) {
    "use strict";
    hn(t, e);
    function t(r, a) {
      yn(this, t);
      var i;
      return (i = _n(this, t, [r]), We(i, "code", void 0), i.name = "TurnstileError", i.code = a, i);
    }
    return t;
  })(Ct(Error));
  var ya = RegExp("^https:\\/\\/challenges(?:\\.fed)?\\.cloudflare\\.com\\/turnstile\\/v0(\\/.*)?\\/api\\.js", "u"), Oo = RegExp("\\/turnstile\\/v0(\\/.*)?\\/api\\.js", "u");
  function b(e, t) {
    var r = ("[Cloudflare Turnstile] ").concat(e, ".");
    throw new En(r, t);
  }
  function T(e) {
    console.warn(("[Cloudflare Turnstile] ").concat(e));
  }
  function lt(e) {
    return e.startsWith(Rt) ? e.slice(Rt.length) : null;
  }
  function G(e) {
    return ("").concat(Rt).concat(e);
  }
  function Mt(e, t) {
    var r = !0, a = !1, i = void 0;
    try {
      for (var l = Object.getOwnPropertySymbols(e)[Symbol.iterator](), s; !(r = (s = l.next()).done); r = !0) {
        var d = s.value, v = Object.getOwnPropertyDescriptor(e, d), p = v === void 0 ? void 0 : Reflect.get(v, "value");
        if (t(p)) return p;
      }
    } catch (g) {
      (a = !0, i = g);
    } finally {
      try {
        !r && l.return != null && l.return();
      } finally {
        if (a) throw i;
      }
    }
  }
  function ct() {
    var e = ya, t = document.currentScript;
    if (A(t, HTMLScriptElement) && e.test(t.src)) return t;
    var r = document.querySelectorAll("script"), a = !0, i = !1, l = void 0;
    try {
      for (var s = r[Symbol.iterator](), d; !(a = (d = s.next()).done); a = !0) {
        var v = d.value;
        if (A(v, HTMLScriptElement) && e.test(v.src)) return v;
      }
    } catch (p) {
      (i = !0, l = p);
    } finally {
      try {
        !a && s.return != null && s.return();
      } finally {
        if (i) throw l;
      }
    }
  }
  function xn() {
    var e = ct();
    e === void 0 && b("Could not find Turnstile valid script tag, some features may not be available", 43777);
    var t = e.src, r;
    try {
      r = new URL(t);
    } catch (l) {
      b("Could not parse Turnstile script tag URL", 43777);
    }
    var a = {
      loadedAsync: !1,
      params: new URLSearchParams(),
      src: t,
      url: r
    };
    (e.async || e.defer) && (a.loadedAsync = !0);
    var i = t.split("?");
    return (i.length > 1 && (a.params = new URLSearchParams(i[1])), a);
  }
  function X() {
    return Date.now();
  }
  function Je(e) {
    try {
      return new URL(e, window.location.href).origin;
    } catch (t) {
      return;
    }
  }
  function er(e, t, r) {
    if (r === void 0 || r === "") {
      if (0) var a;
      return;
    }
    e == null || e.postMessage(t, r);
  }
  function ne(e, t, r) {
    er(e.contentWindow, t, r);
  }
  var Tn = 16, ha = 1, wn = 0, Rn = 1, Sn = 2, In = 3, An = 4, On = 5, kn = 6, Cn = 7;
  function ba(e, t) {
    try {
      var r = new Error().stack;
      return typeof r != "string" ? void 0 : [e, Math.max(0, Math.floor(X() - t)), r, ha];
    } catch (a) {
      return;
    }
  }
  function ye(e, t) {
    return ba(e, t.turnstileLoadInitTimeTsMs);
  }
  function Mn(e) {
    return e[3] === void 0 ? [e[0], e[1], e[2]] : [e[0], e[1], e[2], e[3]];
  }
  function ze(e) {
    var t;
    return (t = e == null ? void 0 : e.slice(-Tn).map(Mn)) !== null && t !== void 0 ? t : [];
  }
  function dt(e, t) {
    if (!t) return !1;
    if (e.length > 0) {
      var r = e[e.length - 1];
      if (r[0] === t[0] && r[2] === t[2]) {
        var a, i, l = ((a = r[3]) !== null && a !== void 0 ? a : 1) + ((i = t[3]) !== null && i !== void 0 ? i : 1);
        return l === r[3] ? !1 : (r[3] = l, !0);
      }
    }
    for (e.push(Mn(t)); e.length > Tn; ) e.shift();
    return !0;
  }
  function Lt(e) {
    var t, r;
    return (t = (r = e.kills) === null || r === void 0 ? void 0 : r.includes("gcs")) !== null && t !== void 0 ? t : !1;
  }
  function st(e, t) {
    return Lt(e) ? !1 : dt(e.gcs, t);
  }
  function Ea(e) {
    var t = ze(e.gcs);
    return t.length > 0 ? t : void 0;
  }
  function ft(e) {
    if (!Lt(e)) return Ea(e);
  }
  function Nt(e, t) {
    if (t.isInitialized) {
      var r = ft(t);
      if (r) {
        var a = t.shadow.querySelector(("#").concat(G(e)));
        a && ne(a, {
          cs: r,
          event: "gcs",
          source: J,
          widgetId: e
        }, t.iframeOrigin);
      }
    }
  }
  function Se(e, t, r) {
    var a = st(t, r);
    return (a && Nt(e, t), a);
  }
  function K(e, t) {
    return e.indexOf(t) !== -1;
  }
  var xa = ["bg-bg", "da-dk", "de-de", "el-gr", "ja-jp", "ms-my", "ru-ru", "sk-sk", "sl-si", "sr-ba", "tl-ph", "uk-ua"], Ta = ["ar-eg", "es-es", "cs-cz", "fa-ir", "fr-fr", "hr-hr", "hu-hu", "id-id", "it-it", "lv-lv", "nb-no", "nl-nl", "pl-pl", "pt-br", "th-th", "tr-tr", "ro-ro"], Ln = "https://challenges.cloudflare.com", Nn = [Ln, "https://challenges-staging.cloudflare.com", "https://challenges.fed.cloudflare.com"];
  function Pt(e, t, r) {
    var a, i = Ln, l = (a = r == null ? void 0 : r.origin) !== null && a !== void 0 ? a : i;
    if (t) {
      var s;
      return (s = e["base-url"]) !== null && s !== void 0 ? s : l;
    }
    return l;
  }
  function tr(e, t, r, a, i, l, s, d, v) {
    var p = Pt(r, i, d), g = l !== void 0 && l !== "" ? ("h/").concat(l, "/") : "", w = v !== void 0 && v !== "" ? ("&").concat(v) : "", k = r["feedback-enabled"] === !1 ? "fbD" : "fbE", H = r.chlPageOfflabel === !0 ? "&offlabel=true" : "";
    return ("").concat(p, "/cdn-cgi/challenge-platform/").concat(g, "turnstile/f/av0/rch").concat(a, "/").concat(e, "/").concat(t, "/").concat(r.theme, "/").concat(k, "/").concat(s, "/").concat(r.size, "?lang=").concat(r.language).concat(H).concat(w);
  }
  var rr = function (t) {
    var r, a, i, l, s = window.innerWidth < 400, d = t.state !== It.FailureFeedbackCode && (t.state === It.FailureFeedback || t.state === It.FailureHavingTroubles || t.errorCode === void 0 || t.errorCode === 0), v = K(xa, (r = (i = t.displayLanguage) === null || i === void 0 ? void 0 : i.toLowerCase()) !== null && r !== void 0 ? r : "nonexistent"), p = K(Ta, (a = (l = t.displayLanguage) === null || l === void 0 ? void 0 : l.toLowerCase()) !== null && a !== void 0 ? a : "nonexistent");
    return s ? wa({
      isModeratelyVerbose: p,
      isSmallerFeedback: d,
      isVerboseLanguage: v
    }) : d && v ? "680px" : d && p ? "670px" : d ? "650px" : v ? "690px" : "680px";
  }, wa = function (t) {
    var r = t.isVerboseLanguage, a = t.isSmallerFeedback, i = t.isModeratelyVerbose;
    return a && r ? "660px" : a && i ? "620px" : a ? "600px" : r ? "770px" : i ? "740px" : "730px";
  };
  var Ra = 5000, Sa = "auto-troubleshoot-click";
  function Ia(e, t) {
    var r = Pt(e.params, !1, t), a = ("h/").concat("b", "/");
    return ("").concat(r, "/cdn-cgi/challenge-platform/").concat(a, "fr");
  }
  var Fn = function (t, r, a, i, l) {
    var s, d, v, p, g, w, k;
    if (i === void 0 || i === "" || a === void 0 || a === "") return !1;
    var H = Ia(t, l), R = new FormData();
    (R.append("consent", "on"), R.append("origin", r), R.append("issue", Sa), R.append("description", ""), R.append("rayId", a), R.append("sitekey", (s = t.params.sitekey) !== null && s !== void 0 ? s : ""), R.append("rcV", (d = t.rcV) !== null && d !== void 0 ? d : ""), R.append("cfChlOut", (v = t.cfChlOut) !== null && v !== void 0 ? v : ""), R.append("cfChlOutS", (p = t.cfChlOutS) !== null && p !== void 0 ? p : ""), R.append("mode", (g = t.mode) !== null && g !== void 0 ? g : ""), R.append("errorCode", String((w = t.errorCode) !== null && w !== void 0 ? w : 0)), R.append("frMd", i), R.append("displayLanguage", (k = t.displayLanguage) !== null && k !== void 0 ? k : ""));
    try {
      if (typeof navigator != "undefined" && typeof navigator.sendBeacon == "function" && navigator.sendBeacon(H, R)) return !0;
    } catch (F) {
      T(("auto feedback report: sendBeacon threw synchronously, falling through to fetch (").concat(nr(F), ")"));
    }
    try {
      return (fetch(H, ke({
        body: R,
        keepalive: !0,
        method: "POST",
        mode: "no-cors"
      }, Pn())), !0);
    } catch (F) {
      T(("auto feedback report: keepalive fetch threw synchronously, falling through to plain fetch (").concat(nr(F), ")"));
    }
    try {
      fetch(H, ke({
        body: R,
        method: "POST",
        mode: "no-cors"
      }, Pn()));
    } catch (F) {
      T(("auto feedback report: all transports failed (").concat(nr(F), ")"));
    }
    return !1;
  };
  function Pn() {
    return typeof AbortSignal == "undefined" || typeof AbortSignal.timeout != "function" ? {} : {
      signal: AbortSignal.timeout(Ra)
    };
  }
  function nr(e) {
    return A(e, Error) ? e.message : "unknown error";
  }
  var Dt = null, pt = 0, Un = function () {
    if ((pt++, pt === 1)) {
      var t = document.querySelector("meta[http-equiv=\"refresh\"]");
      t && (Dt = t.getAttribute("content"), t.remove());
    }
  }, Hn = function () {
    if ((pt > 0 && pt--, pt === 0 && Dt !== null)) {
      var t = document.createElement("meta");
      (t.httpEquiv = "refresh", t.content = Dt, Dt = null, document.head.appendChild(t));
    }
  }, ar = Symbol(), Aa = "host-origin", je = function (t) {
    (t.feedbackPopup && !t.feedbackPopup.closed && t.feedbackPopup.close(), t.feedbackPopup = void 0, t.feedbackPopupOrigin = void 0);
  };
  function Wn(e) {
    return e.endsWith("-fr") ? e : ("").concat(e, "-fr");
  }
  function Vn(e) {
    var t, r, a, i = (a = document.querySelector(("#").concat(e))) === null || a === void 0 || (r = a.parentElement) === null || r === void 0 || (t = r.parentElement) === null || t === void 0 ? void 0 : t.parentElement;
    return A(i, HTMLDivElement) ? i : null;
  }
  function Dn(e) {
    if (!((typeof e == "undefined" ? "undefined" : D(e)) !== "object" || e === null)) {
      var t = Object.getOwnPropertyDescriptor(e, "cleanup"), r = t === void 0 ? void 0 : Reflect.get(t, "value");
      if (typeof r == "function") return function () {
        Reflect.apply(r, void 0, []);
      };
    }
  }
  function qn(e) {
    var t, r = Dn((t = Object.getOwnPropertyDescriptor(e, ar)) === null || t === void 0 ? void 0 : t.value);
    if (r) return r;
    var a = !0, i = !1, l = void 0;
    try {
      for (var s = Object.getOwnPropertySymbols(e)[Symbol.iterator](), d; !(a = (d = s.next()).done); a = !0) {
        var v = d.value, p, g = Dn((p = Object.getOwnPropertyDescriptor(e, v)) === null || p === void 0 ? void 0 : p.value);
        if (g) return g;
      }
    } catch (w) {
      (i = !0, l = w);
    } finally {
      try {
        !a && s.return != null && s.return();
      } finally {
        if (i) throw l;
      }
    }
  }
  function Oa(e, t) {
    Object.defineProperty(e, ar, {
      configurable: !0,
      enumerable: !1,
      value: {
        cleanup: t
      }
    });
  }
  function ka(e) {
    Reflect.deleteProperty(e, ar);
  }
  function Ca(e) {
    var t = new URL(e, window.location.href), r = new URLSearchParams(t.hash.startsWith("#") ? t.hash.slice(1) : t.hash);
    return (r.set(Aa, window.location.origin), t.hash = r.toString(), t.toString());
  }
  var ir = function (t, r, a, i, l) {
    var s, d, v = Wn(t), p = Pt(r.params, !1, i), g = ("h/").concat("b", "/"), w = Ca(("").concat(p, "/cdn-cgi/challenge-platform/").concat(g, "fr/").concat(lt(t), "/").concat(r.displayLanguage, "/").concat((d = r.params.theme) !== null && d !== void 0 ? d : r.theme, "/").concat(a));
    if ((je(r), window.top !== window.self)) {
      var k = window.open(w, "_blank");
      if (k) {
        (r.feedbackPopupOrigin = Je(w), r.feedbackPopup = k);
        var H = window.setInterval(function () {
          k.closed && (window.clearInterval(H), r.feedbackPopupCloseCheck = void 0, l == null || l());
        }, 500);
        r.feedbackPopupCloseCheck = H;
        return;
      }
      T("Unable to open feedback report popup, falling back to the embedded feedback overlay.");
    }
    r.wrapper.parentNode || b(("Cannot initialize Widget, Element not found (#").concat(t, ")."), 3074);
    var R = Vn(v);
    if (R) {
      var F;
      (F = qn(R)) === null || F === void 0 || F();
    }
    var C = document.createElement("div");
    (C.style.position = "fixed", C.style.zIndex = "2147483646", C.style.width = "100vw", C.style.height = "100vh", C.style.top = "0", C.style.left = "0", C.style.transformOrigin = "center center", C.style.overflowX = "hidden", C.style.overflowY = "auto", C.style.background = "rgba(0,0,0,0.4)");
    var N = document.createElement("div");
    (N.className = "cf-wrapper-turnstile-feedback", N.style.display = "table-cell", N.style.verticalAlign = "middle", N.style.width = "100vw", N.style.height = "100vh");
    var I = document.createElement("div");
    (I.className = "cf-turnstile-feedback", I.id = "cf-fr-id", I.style.width = "100vw", I.style.maxWidth = "500px", I.style.height = rr(r), I.style.position = "relative", I.style.zIndex = "2147483647", I.style.backgroundColor = "#ffffff", I.style.borderRadius = "5px", I.style.left = "0px", I.style.top = "0px", I.style.overflow = "hidden", I.style.margin = "0px auto");
    var be = function () {
      I.style.height = rr(r);
    }, oe = function () {
      var ae;
      (ka(C), r.feedbackIframeOrigin = void 0, window.removeEventListener("resize", be), (ae = C.parentNode) === null || ae === void 0 || ae.removeChild(C), l == null || l());
    }, W = document.createElement("iframe");
    (W.id = v, W.setAttribute("src", w), W.setAttribute("title", "Turnstile feedback report"), W.setAttribute("allow", "cross-origin-isolated; fullscreen"), W.setAttribute("sandbox", "allow-same-origin allow-scripts allow-popups allow-forms"), W.setAttribute("scrolling", "yes"), W.style.borderWidth = "0px", W.style.width = "100%", W.style.height = "100%", W.style.overflow = "auto", r.feedbackIframeOrigin = Je(w));
    var O = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    (O.setAttribute("tabindex", "0"), O.setAttribute("role", "button"), O.setAttribute("aria-label", "Close feedback report"), O.style.position = "absolute", O.style.width = "26px", O.style.height = "26px", O.style.zIndex = "2147483647", O.style.cursor = "pointer", r.displayRtl === !0 ? O.style.left = "24px" : O.style.right = "24px", O.style.top = "24px", O.setAttribute("width", "20"), O.setAttribute("height", "20"), O.addEventListener("click", function (Y) {
      (Y.stopPropagation(), oe());
    }), O.addEventListener("keydown", function (Y) {
      (Y.key === "Enter" || Y.key === " ") && (Y.preventDefault(), Y.stopPropagation(), oe());
    }));
    var V = document.createElementNS("http://www.w3.org/2000/svg", "ellipse");
    (V.setAttribute("ry", "12"), V.setAttribute("rx", "12"), V.setAttribute("cy", "12"), V.setAttribute("cx", "12"), V.setAttribute("fill", "none"), V.setAttribute("stroke-width", "0"), O.appendChild(V));
    var z = document.createElementNS("http://www.w3.org/2000/svg", "line");
    (z.setAttribute("stroke-width", "1"), z.setAttribute("fill", "none"), z.setAttribute("x1", "6"), z.setAttribute("x2", "18"), z.setAttribute("y1", "18"), z.setAttribute("y2", "5"));
    var M = document.createElementNS("http://www.w3.org/2000/svg", "line");
    (M.setAttribute("stroke-width", "1"), M.setAttribute("fill", "none"), M.setAttribute("x1", "6"), M.setAttribute("x2", "18"), M.setAttribute("y1", "5"), M.setAttribute("y2", "18"), r.theme === St.Light ? (z.setAttribute("stroke", "#0A0A0A"), M.setAttribute("stroke", "#0A0A0A")) : (z.setAttribute("stroke", "#F2F2F2"), M.setAttribute("stroke", "#F2F2F2")), O.appendChild(z), O.appendChild(M), I.appendChild(W), I.appendChild(O), N.appendChild(I), C.appendChild(N), C.addEventListener("click", oe), r.wrapper.parentNode.appendChild(C), window.addEventListener("resize", be), Oa(C, oe));
  }, vt = function (t) {
    var r, a = Wn(t), i = Vn(a);
    if (i) {
      var l = qn(i);
      if (l) {
        l();
        return;
      }
      (T("Unable to find feedback overlay cleanup handler. Removing overlay without cleanup."), (r = i.parentNode) === null || r === void 0 || r.removeChild(i));
    }
  };
  var Ma = 900, La = 45, Na = 50;
  function Pa(e) {
    return A(e, ShadowRoot);
  }
  function Da(e, t, r) {
    var a = e.widgetMap.get(t);
    ((a == null ? void 0 : a.retryTimeout) !== void 0 && (window.clearTimeout(a.retryTimeout), a.retryTimeout = void 0), T(("Cannot find Widget ").concat(r, ", consider using turnstile.remove() to clean up a widget.")), e.widgetMap.delete(t));
  }
  function Fa(e) {
    e.watchCatSeq++;
    var t = [], r = !0, a = !1, i = void 0;
    try {
      for (var l = e.widgetMap[Symbol.iterator](), s; !(r = (s = l.next()).done); r = !0) {
        var d = Ve(s.value, 2), v = d[0], p = d[1], g = G(v), w = p.shadow;
        if (!Pa(w) || !p.wrapper.isConnected) {
          p.watchcat.missingWidgetWarning || (p.watchcat.missingWidgetWarning = !0, t.push({
            widgetElId: g,
            widgetId: v
          }));
          continue;
        }
        var k = w.querySelector(("#").concat(g));
        if (k === null) {
          p.watchcat.missingWidgetWarning || (p.watchcat.missingWidgetWarning = !0, t.push({
            widgetElId: g,
            widgetId: v
          }));
          continue;
        }
        if ((p.watchcat.seq = e.watchCatSeq, p.watchcat.lastAckedSeq === 0 && (p.watchcat.lastAckedSeq = e.watchCatSeq), !(p.isComplete || p.isFailed || p.feedbackOpen))) {
          var H = p.watchcat.seq - 1 - La, R = p.watchcat.lastAckedSeq < H, F = p.watchcat.seq - 1 - Na, C = p.isOverrunning && p.watchcat.overrunBeginSeq !== 0 && p.watchcat.overrunBeginSeq < F;
          if ((p.isExecuting || !p.isInitialized || !p.isStale && !p.isExecuted) && p.watchcat.lastAckedSeq !== 0 && R || C) {
            var N, I;
            (p.watchcat.lastAckedSeq = 0, p.watchcat.seq = 0, p.isExecuting = !1);
            var be = function (u, f) {
              console.log(("Turnstile Widget seem to have ").concat(u, ": "), f);
            };
            be(R ? "hung" : "crashed", v);
            var oe = R ? Ot : kt;
            if (((I = e.internalMsgHandler) === null || I === void 0 || I.call(e, {
              code: oe,
              event: "fail",
              rcV: (N = p.nextRcV) !== null && N !== void 0 ? N : me,
              source: J,
              widgetId: v
            }), 0)) var W;
            continue;
          }
          ne(k, {
            event: "meow",
            seq: e.watchCatSeq,
            source: J,
            widgetId: v
          }, p.iframeOrigin);
        }
      }
    } catch (n) {
      (a = !0, i = n);
    } finally {
      try {
        !r && l.return != null && l.return();
      } finally {
        if (a) throw i;
      }
    }
    var O = !0, V = !1, z = void 0;
    try {
      for (var M = t[Symbol.iterator](), Y; !(O = (Y = M.next()).done); O = !0) {
        var ae = Y.value, j = ae.widgetElId, x = ae.widgetId;
        Da(e, x, j);
      }
    } catch (n) {
      (V = !0, z = n);
    } finally {
      try {
        !O && M.return != null && M.return();
      } finally {
        if (V) throw z;
      }
    }
    t.length > 0 && e.widgetMap.size === 0 && mt(e);
  }
  function or(e) {
    var t, r;
    (r = (t = e).watchCatInterval) !== null && r !== void 0 || (t.watchCatInterval = setInterval(function () {
      Fa(e);
    }, Ma));
  }
  function mt(e) {
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
    e.watchCatInterval !== null && (e.widgetMap.size === 0 || t) && (clearInterval(e.watchCatInterval), e.watchCatInterval = null);
  }
  var lr = Symbol();
  function Jn(e) {
    return (typeof e == "undefined" ? "undefined" : D(e)) === "object" && e !== null ? e : void 0;
  }
  function ur(e) {
    return (typeof e == "undefined" ? "undefined" : D(e)) === "object" && e !== null && ("widgetMap" in e) && A(e.widgetMap, Map) && ("upgradeAttempts" in e) && typeof e.upgradeAttempts == "number" && ("upgradeCompletedCount" in e) && typeof e.upgradeCompletedCount == "number";
  }
  function Ua(e, t) {
    Object.defineProperty(e, lr, {
      configurable: !0,
      enumerable: !1,
      value: t
    });
  }
  function Ha(e) {
    var t = Object.getOwnPropertyDescriptor(e, lr), r = t === void 0 ? void 0 : Reflect.get(t, "value");
    if (ur(r)) return r;
    var a = Mt(e, ur);
    if (a) return a;
  }
  function zn(e) {
    Reflect.deleteProperty(e, lr);
    var t = !0, r = !1, a = void 0;
    try {
      for (var i = Object.getOwnPropertySymbols(e)[Symbol.iterator](), l; !(t = (l = i.next()).done); t = !0) {
        var s = l.value, d = Object.getOwnPropertyDescriptor(e, s), v = d === void 0 ? void 0 : Reflect.get(d, "value");
        ur(v) && Reflect.deleteProperty(e, s);
      }
    } catch (p) {
      (r = !0, a = p);
    } finally {
      try {
        !t && i.return != null && i.return();
      } finally {
        if (r) throw a;
      }
    }
  }
  function Wa(e) {
    return !Number.isFinite(e.apiJsReloadBackoffMs) || e.apiJsReloadBackoffMs <= 0 ? qe : Math.min(e.apiJsReloadBackoffMs, rt);
  }
  function Va(e) {
    return !Number.isFinite(e.apiJsReloadNextAllowedTsMs) || e.apiJsReloadNextAllowedTsMs <= 0 ? 0 : e.apiJsReloadNextAllowedTsMs;
  }
  function Bn(e, t) {
    var r = Reflect.get(e, t);
    return typeof r == "number" ? r : 0;
  }
  function jn(e, t) {
    var r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : ct;
    t.upgradeAttempts++;
    var a = r();
    if (!(a != null && a.parentNode)) return !1;
    var i = Jn(e);
    if (!i) return !1;
    var l = a.nonce;
    Ua(i, t);
    var s = new URL(a.src), d = document.createElement("script");
    (s.searchParams.set("_upgrade", "true"), s.searchParams.set("_cb", String(Date.now())), d.async = !0, l && (d.nonce = l), d.setAttribute("crossorigin", "anonymous"), d.src = s.toString());
    try {
      return (a.parentNode.replaceChild(d, a), !0);
    } catch (v) {
      if (!A(v, DOMException)) throw v;
      return (zn(i), !1);
    }
  }
  function Kn(e, t, r) {
    var a = Jn(e);
    if (!a) return !1;
    var i = Ha(a);
    if (!i) return !1;
    var l = i.apiJsMismatchReloadPending;
    (t.isReady = i.isReady, t.isRecaptchaCompatibilityMode = i.isRecaptchaCompatibilityMode, t.gcs = ze(i.gcs), t.lastWidgetIdx = i.lastWidgetIdx, t.scriptWasLoadedAsync = i.scriptWasLoadedAsync, t.apiJsReloadBackoffMs = l ? qe : Wa(i), t.apiJsReloadNextAllowedTsMs = Va(i), t.apiJsMismatchReloadAttempts = Bn(i, "apiJsMismatchReloadAttempts"), t.apiJsMismatchReloadCompletedCount = Bn(i, "apiJsMismatchReloadCompletedCount") + (l ? 1 : 0), t.apiJsMismatchReloadPending = !1, t.upgradeAttempts = i.upgradeAttempts, t.upgradeCompletedCount = i.upgradeCompletedCount + 1, t.turnstileLoadInitTimeTsMs = X(), t.watchCatInterval = null, t.watchCatSeq = i.watchCatSeq, t.widgetMap = i.widgetMap);
    var s = !0, d = !1, v = void 0;
    try {
      for (var p = t.widgetMap.values()[Symbol.iterator](), g; !(s = (g = p.next()).done); s = !0) {
        var w = g.value;
        w.gcs = ze(w.gcs);
      }
    } catch (k) {
      (d = !0, v = k);
    } finally {
      try {
        !s && p.return != null && p.return();
      } finally {
        if (d) throw v;
      }
    }
    return (mt(i, !0), i.msgHandler && window.removeEventListener("message", i.msgHandler), zn(a), r(), !0);
  }
  function cr(e) {
    return K(["auto", "dark", "light"], e);
  }
  function dr(e) {
    return K(["auto", "never"], e);
  }
  function sr(e) {
    return e > 0 && e < 900000;
  }
  function fr(e) {
    return e > 0 && e < 360000;
  }
  var qa = RegExp("^[0-9A-Za-z_-]{3,100}$", "u");
  function Gn(e) {
    return qa.test(e);
  }
  var Ba = RegExp("^[a-z0-9_-]{0,32}$", "iu");
  function pr(e) {
    return e === void 0 ? !0 : typeof e == "string" && Ba.test(e);
  }
  var Ja = RegExp("^[a-z0-9_\\-=]{0,255}$", "iu");
  function vr(e) {
    return e === void 0 ? !0 : typeof e == "string" && Ja.test(e);
  }
  function mr(e) {
    return K([Z.Normal, Z.Compact, Z.Invisible, Z.Flexible], e);
  }
  function gr(e) {
    return K(["auto", "manual", "never"], e);
  }
  function _r(e) {
    return K(["auto", "manual", "never"], e);
  }
  var za = RegExp("^[a-z]{2,3}([-_][a-z]{2})?$", "iu");
  function yr(e) {
    return e === "auto" || za.test(e);
  }
  function hr(e) {
    return K(["always", "execute", "interaction-only"], e);
  }
  function Xn(e) {
    return K(["true", "false"], e);
  }
  function br(e) {
    return K(["render", "execute"], e);
  }
  var fu = RegExp("^[0-9a-z_\\-.]{5,2000}$", "iu");
  function Er(e) {
    var t = new URLSearchParams();
    if (0) {
      var r;
      if (r != null && r !== "") var a;
    }
    if ((e.params["offlabel-show-privacy"] !== void 0 && t.set("offlabel_show_privacy", String(e.params["offlabel-show-privacy"])), e.params["offlabel-show-help"] !== void 0 && t.set("offlabel_show_help", String(e.params["offlabel-show-help"])), !(t.size === 0 || t.toString() === ""))) return t.toString();
  }
  function Yn(e, t) {
    if ((e.isResetting = !1, t)) {
      t(String(fn));
      return;
    }
    b("Could not load challenge from challenges.cloudflare.com.", 161);
  }
  function Qn(e, t) {
    return e ? t ? !0 : K(Nn, e) : !1;
  }
  function $n() {
    for (var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : window, t = e; t && t.top !== t && !t.location.href.startsWith("http"); ) t = t.top;
    return t == null ? void 0 : t.location.href;
  }
  var oa = Symbol(), ja = "Turnstile has already been rendered in this container. The render attempt was rejected.", Ka = "Turnstile skipped implicit render because a widget already exists in this container.", xr = void 0, Ga = function (e) {
    return e.styleSheets.length;
  };
  function Rr(e) {
    return Reflect.get(window, e);
  }
  function Sr(e) {
    var t = Rr(e);
    return typeof t == "function" ? function () {
      for (var r = arguments.length, a = new Array(r), i = 0; i < r; i++) a[i] = arguments[i];
      return Reflect.apply(t, window, a);
    } : void 0;
  }
  function Zn(e, t) {
    return e == null ? t : Number(e);
  }
  function Xa(e) {
    return e === "new" || e === "crashed_retry" || e === "failure_retry" || e === "stale_execute" || e === "auto_expire" || e === "auto_timeout" || e === "manual_refresh" || e === "api" || e === "check_delays" || e === "upgrade_reload" || e === "time_check_cached_warning_aux" || e === "js_cookies_missing_aux" || e === "redirecting_text_overrun";
  }
  function Ya(e) {
    var t = JSON.stringify(e);
    return JSON.parse(t);
  }
  function ea(e) {
    return (typeof e == "undefined" ? "undefined" : D(e)) === "object" && e !== null && ("clearPendingApiJsReloadRequest" in e) && typeof e.clearPendingApiJsReloadRequest == "function" && ("rejectPendingApiJsReloadRequest" in e) && typeof e.rejectPendingApiJsReloadRequest == "function" && ("rearmTimedUpgrade" in e) && typeof e.rearmTimedUpgrade == "function" && ("reloadAfterUpgrade" in e) && typeof e.reloadAfterUpgrade == "function";
  }
  function ta(e) {
    if (!((typeof e == "undefined" ? "undefined" : D(e)) !== "object" || e === null)) {
      var t = Object.getOwnPropertyDescriptor(e, oa), r = t === void 0 ? void 0 : Reflect.get(t, "value");
      if (ea(r)) return r;
      var a = Mt(e, ea);
      if (a) return a;
    }
  }
  var m = {
    apiJsMismatchReloadAttempts: 0,
    apiJsMismatchReloadCompletedCount: 0,
    apiJsMismatchReloadPending: !1,
    apiJsReloadBackoffMs: qe,
    apiJsReloadNextAllowedTsMs: 0,
    apiVersion: 1,
    gcs: [],
    isReady: !1,
    isRecaptchaCompatibilityMode: !1,
    lastWidgetIdx: 0,
    scriptUrl: "undefined",
    scriptUrlParsed: void 0,
    scriptWasLoadedAsync: !1,
    turnstileLoadInitTimeTsMs: X(),
    upgradeAttempts: 0,
    upgradeCompletedCount: 0,
    watchCatInterval: null,
    watchCatSeq: 0,
    widgetMap: new Map()
  }, yt, zt, Kt;
  function Qa(e) {
    var t = !0, r = !1, a = void 0;
    try {
      for (var i = m.widgetMap[Symbol.iterator](), l; !(t = (l = i.next()).done); t = !0) {
        var s = Ve(l.value, 2), d = s[0], v = s[1];
        if (v.wrapper.parentElement === e || v.wrapper !== e && v.wrapper.contains(e) || v.shadow.contains(e)) return d;
      }
    } catch (p) {
      (r = !0, a = p);
    } finally {
      try {
        !t && i.return != null && i.return();
      } finally {
        if (r) throw a;
      }
    }
    return null;
  }
  function Ft(e) {
    if (typeof e == "string") {
      var t = lt(e);
      return t !== null && m.widgetMap.has(t) ? t : m.widgetMap.has(e) ? e : null;
    }
    return Qa(e);
  }
  function $a(e) {
    return e === "implicit" ? Ka : ja;
  }
  function ra(e, t) {
    return e === "explicit" && (t == null ? void 0 : t.renderSource) === "implicit";
  }
  function Ir() {
    yt !== void 0 && (window.clearTimeout(yt), yt = void 0);
  }
  function ua() {
    var e = !0, t = !1, r = void 0;
    try {
      for (var a = m.widgetMap.values()[Symbol.iterator](), i; !(e = (i = a.next()).done); e = !0) {
        var l = i.value;
        if (l.chlPageData !== void 0 && l.chlPageData !== "") return !0;
      }
    } catch (s) {
      (t = !0, r = s);
    } finally {
      try {
        !e && a.return != null && a.return();
      } finally {
        if (t) throw r;
      }
    }
    return !1;
  }
  function _t(e) {
    var t = m.widgetMap.get(e), r = G(e);
    if (t !== void 0) {
      var a = Ne(t, r);
      a !== null && ne(a, {
        apiJsMismatchReloadAttempts: m.apiJsMismatchReloadAttempts,
        apiJsMismatchReloadCompletedCount: m.apiJsMismatchReloadCompletedCount,
        event: "reloadApiJsRejected",
        source: J,
        widgetId: e
      }, t.iframeOrigin);
    }
  }
  function Ar() {
    var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, t = e.preserveMismatchReloadPending, r = t === void 0 ? !1 : t;
    (Kt = void 0, r || (m.apiJsMismatchReloadPending = !1), zt !== void 0 && (window.clearTimeout(zt), zt = void 0));
  }
  function la() {
    var e = Kt;
    (Ar(), e !== void 0 && _t(e));
  }
  function Za() {
    return X() < m.apiJsReloadNextAllowedTsMs;
  }
  function ei() {
    var e = m.apiJsReloadBackoffMs, t = Number.isFinite(e) && e > 0 ? Math.min(e, rt) : qe, r = Math.round(t * (0.8 + Math.random() * 0.4));
    (m.apiJsReloadNextAllowedTsMs = X() + r, m.apiJsReloadBackoffMs = Math.min(t * 2, rt));
  }
  function ti(e) {
    (Ar({
      preserveMismatchReloadPending: !0
    }), m.apiJsMismatchReloadPending = !0, Kt = e, zt = window.setTimeout(function () {
      la();
    }, Kr));
  }
  function Or() {
    (Ir(), !ua() && (yt = window.setTimeout(function () {
      (yt = void 0, fa());
    }, Xr)));
  }
  function Tr(e, t) {
    da(e, t, "");
  }
  var kr = [];
  function na() {
    m.isReady = !0;
    var e = !0, t = !1, r = void 0;
    try {
      for (var a = kr[Symbol.iterator](), i; !(e = (i = a.next()).done); e = !0) {
        var l = i.value;
        l();
      }
    } catch (s) {
      (t = !0, r = s);
    } finally {
      try {
        !e && a.return != null && a.return();
      } finally {
        if (t) throw r;
      }
    }
  }
  function aa(e, t) {
    e.onerror = function () {
      Yn(t, t.cbError);
    };
  }
  function ca(e, t) {
    var r, a = (r = e.params["response-field"]) !== null && r !== void 0 ? r : !0, i = m.isRecaptchaCompatibilityMode, l = ("").concat(t, "_response"), s = ("").concat(t, "_g_response"), d = (!a || A(document.querySelector(("#").concat(l)), HTMLInputElement)) && (!i || A(document.querySelector(("#").concat(s)), HTMLInputElement));
    if (!(e.responseElementsBuilt && d)) {
      if (a && !A(document.querySelector(("#").concat(l)), HTMLInputElement)) {
        var v, p = document.createElement("input");
        (p.type = "hidden", p.name = (v = e.params["response-field-name"]) !== null && v !== void 0 ? v : zr, p.id = l, e.wrapper.appendChild(p));
      }
      if (i && !A(document.querySelector(("#").concat(s)), HTMLInputElement)) {
        var g = document.createElement("input");
        (g.type = "hidden", g.name = jr, g.id = s, e.wrapper.appendChild(g));
      }
      e.responseElementsBuilt = !0;
    }
  }
  function da(e, t, r) {
    ca(e, t);
    var a = document.querySelector(("#").concat(t, "_response"));
    if ((a !== null && A(a, HTMLInputElement) && (a.value = r), m.isRecaptchaCompatibilityMode)) {
      var i = document.querySelector(("#").concat(t, "_g_response"));
      i !== null && A(i, HTMLInputElement) && (i.value = r);
    }
  }
  function Ge(e, t) {
    var r, a;
    return (r = (a = t.kills) === null || a === void 0 ? void 0 : a.includes(e)) !== null && r !== void 0 ? r : !1;
  }
  function Ut(e, t) {
    var r, a = (r = t.params.size) !== null && r !== void 0 ? r : Z.Normal, i = t.mode;
    switch (i) {
      case ge.NonInteractive:
      case ge.Managed:
        switch ((e.style.opacity = "", e.style.position = "", e.style.left = "", e.style.top = "", e.style.visibility = "", e.style.pointerEvents = "", e.style.zIndex = "", a)) {
          case Z.Compact:
            (e.style.width = "150px", e.style.height = "140px");
            break;
          case Z.Invisible:
            b(("Invalid value for parameter \"size\", expected \"").concat(Z.Compact, "\", \"").concat(Z.Flexible, "\", or \"").concat(Z.Normal, "\", got \"").concat(a, "\""), 2817);
          case Z.Normal:
            (e.style.width = "300px", e.style.height = "65px");
            break;
          case Z.Flexible:
            (e.style.width = "100%", e.style.maxWidth = "100vw", e.style.minWidth = "300px", e.style.height = "65px");
            break;
          default:
            break;
        }
        break;
      case ge.Invisible:
        (Ge("floating-invisible", t) ? (e.style.width = "0", e.style.height = "0", e.style.position = "absolute", e.style.visibility = "hidden") : (e.style.width = "1px", e.style.height = "1px", e.style.opacity = "0.01", e.style.position = "fixed", e.style.left = "0", e.style.top = "0", e.style.visibility = "visible", e.style.pointerEvents = "none", e.style.zIndex = "-1"), e.setAttribute("tabindex", "-1"), e.setAttribute("aria-hidden", "true"));
        break;
      default:
        b(("Invalid value for parameter \"mode\", expected \"").concat(ge.NonInteractive, "\", \"").concat(ge.Managed, "\" or \"").concat(ge.Invisible, "\", got \"").concat(String(i), "\""), 2818);
    }
  }
  function ia(e) {
    (e.style.width = "1px", e.style.height = "1px", e.style.opacity = "0.01", e.style.position = "fixed", e.style.left = "0", e.style.top = "0", e.style.visibility = "visible", e.style.pointerEvents = "none", e.style.zIndex = "-1");
  }
  function ri(e, t) {
    var r = t.get("turnstile_iframe_alt");
    r !== void 0 && r !== "" && (e.title = r);
  }
  function Ne(e, t) {
    return e.shadow.querySelector(("#").concat(t));
  }
  function ni(e, t) {
    var r, a;
    return (r = (a = e.wrapper.parentNode) === null || a === void 0 ? void 0 : a.querySelector(("#").concat(t, "-fr"))) !== null && r !== void 0 ? r : null;
  }
  function ai(e) {
    var t, r;
    return ((r = e.feedbackPopup) === null || r === void 0 ? void 0 : r.closed) === !0 ? (e.feedbackPopup = void 0, e.feedbackPopupOrigin = void 0, null) : (t = e.feedbackPopup) !== null && t !== void 0 ? t : null;
  }
  function jt(e, t) {
    var r, a, i = (r = (a = ni(e, t)) === null || a === void 0 ? void 0 : a.contentWindow) !== null && r !== void 0 ? r : null;
    if (i !== null) return {
      targetOrigin: e.feedbackIframeOrigin,
      targetWindow: i
    };
    var l = ai(e);
    return {
      targetOrigin: l === null ? void 0 : e.feedbackPopupOrigin,
      targetWindow: l
    };
  }
  function ii(e) {
    if ((typeof e == "undefined" ? "undefined" : D(e)) !== "object" || e === null) return !1;
    var t = e;
    return t.source === J && typeof t.event == "string" && typeof t.widgetId == "string";
  }
  function oi(e) {
    return e.isTrusted && ii(e.data);
  }
  function ui(e) {
    return Qn(e.origin, !1);
  }
  function li(e, t, r) {
    var a, i, l = (a = (i = Ne(t, r)) === null || i === void 0 ? void 0 : i.contentWindow) !== null && a !== void 0 ? a : null, s = jt(t, r).targetWindow, d = function (w) {
      return w !== null && e.source === w;
    }, v = e.data.event;
    switch (v) {
      case "requestFeedbackData":
      case "closeFeedbackReportIframe":
        return d(s);
      case "refreshRequest":
        return d(l) || e.data.reason === "feedback_refresh" && d(s);
      case "complete":
      case "fail":
      case "feedbackInit":
      case "food":
      case "init":
      case "interactiveBegin":
      case "interactiveEnd":
      case "interactiveTimeout":
      case "languageUnsupported":
      case "overrunBegin":
      case "overrunEnd":
      case "reject":
      case "reloadApiJsRequest":
      case "reloadRequest":
      case "requestExtraParams":
      case "tokenExpired":
      case "translationInit":
      case "turnstileResults":
      case "widgetStale":
        return d(l);
      default:
        {
          var p = v;
          return !1;
        }
    }
  }
  function wr() {
    return $n(window);
  }
  function Ht(e, t, r) {
    return e === null ? t : Xn(e) ? e === "true" : (T(r(e)), t);
  }
  function ci() {
    try {
      var e = ct();
      if (!e) return;
      var t = e.src, r = !0, a = !1, i = void 0;
      try {
        for (var l = performance.getEntriesByType("resource")[Symbol.iterator](), s; !(r = (s = l.next()).done); r = !0) {
          var d = s.value;
          if (A(d, PerformanceResourceTiming) && d.name.includes(t)) return d;
        }
      } catch (v) {
        (a = !0, i = v);
      } finally {
        try {
          !r && l.return != null && l.return();
        } finally {
          if (a) throw i;
        }
      }
    } catch (v) {
      return;
    }
  }
  var sa = (function () {
    var e = function (n, u, f, c, o, E) {
      return Nr(function () {
        var _, y, L, S, P, q, ue, le, pe, Ee, te;
        return Vr(this, function (Q) {
          switch (Q.label) {
            case 0:
              if ((y = function (ce, de) {
                var B = m.widgetMap.get(u);
                B !== n || B.isComplete || B.isResetting || B.response !== c || (!ce && de !== void 0 && de !== "" && T(de), i(B, f, ce));
              }, L = n.params.sitekey, S = wr(), S === void 0 || S === "")) return (T("Cannot determine Turnstile's embedded location, aborting clearance redemption."), i(n, f, !1), [2]);
              (P = ("h/").concat("b", "/"), q = new URL(S), ue = "https", le = "", pe = ("").concat(ue, "://").concat(q.host, "/cdn-cgi/challenge-platform/").concat(P, "c/").concat(E).concat(le), Q.label = 1);
            case 1:
              return (Q.trys.push([1, 3, , 4]), [4, fetch(pe, {
                body: JSON.stringify({
                  secondaryToken: o,
                  sitekey: L
                }),
                headers: {
                  "Content-Type": "application/json"
                },
                method: "POST",
                redirect: "manual"
              })]);
            case 2:
              return (Ee = Q.sent(), Ee.status === 200 ? y(!0) : y(!1, "Cannot determine Turnstile's embedded location, aborting clearance redemption, are you running Turnstile on a Cloudflare Zone?"), [3, 4]);
            case 3:
              return (te = Q.sent(), y(!1, "Error contacting Turnstile, aborting clearance redemption."), [3, 4]);
            case 4:
              return [2];
          }
        });
      })();
    }, t = function (n, u, f) {
      if (n.params.retry === At.Auto || f) {
        var c;
        if (n.feedbackOpen) {
          n.pendingRetry = {
            crashed: f
          };
          return;
        }
        var o = f ? 0 : 1000 * 2 + ((c = n.params["retry-interval"]) !== null && c !== void 0 ? c : 0);
        n.retryTimeout = window.setTimeout(function () {
          var E = f ? ee.CrashedRetry : ee.FailureRetry;
          R(E, u);
        }, o);
      }
    }, r = function (n, u, f) {
      return n.params.execution === at.Render ? !0 : (u === ee.CrashedRetry || u === ee.FailureRetry || u === ee.CheckDelays || u === ee.UpgradeReload) && n.params.execution === at.Execute && f;
    }, a = function (n, u, f) {
      if (n.feedbackOpen && (n.feedbackOpen = !1, n.feedbackPopupCloseCheck !== void 0 && (window.clearInterval(n.feedbackPopupCloseCheck), n.feedbackPopupCloseCheck = void 0), Hn(), window.postMessage({
        event: "feedbackClose",
        source: J,
        widgetId: f
      }, "*"), n.pendingRetry)) {
        var c = n.pendingRetry.crashed;
        (n.pendingRetry = void 0, t(n, u, c));
      }
    }, i = function (n, u, f) {
      var c;
      (n.response === void 0 && b("[Internal Error] Widget was completed but no response was given", 1362), n.isExecuting = !1, n.isComplete = !0, da(n, u, n.response), (c = n.cbSuccess) === null || c === void 0 || c.call(n, n.response, f));
    }, l = function (n) {
      if (!n) return [];
      for (var u = n.attributes, f = u.length, c = new Array(f), o = 0; o < f; o++) c[o] = u[o].name;
      return c;
    }, s = function () {
      for (var n = {}, u = [], f = document.querySelectorAll("*"), c = 0; c < f.length && u.length < 50; c++) {
        var o = f[c].tagName.toLowerCase();
        o.includes("-") && !n[o] && (n[o] = !0, u.push(o));
      }
      return u;
    }, d = function (n, u, f) {
      if ((n.rcV = u, 0)) var c;
    }, v = function () {
      var n = "abcdefghijklmnopqrstuvwxyz0123456789", u = n.length, f;
      do {
        f = "";
        for (var c = 0; c < 5; c++) f += n.charAt(Math.floor(Math.random() * u));
      } while (m.widgetMap.has(f));
      return f;
    }, p = function (n, u, f) {
      for (; n.msgQueue.length > 0; ) {
        var c = n.msgQueue.pop();
        ne(f, {
          cs: c === it.Execute ? ft(n) : void 0,
          event: c,
          source: J,
          widgetId: u
        }, n.iframeOrigin);
      }
    }, g = function (n) {
      return n.isExecuting;
    }, w = function (n, u) {
      if (u) {
        var f = ["retry-interval", "retry", "size", "theme", "tabindex", "execution", "refresh-expired", "refresh-timeout", "response-field-name", "response-field", "language", "base-url", "appearance", "sitekey", "feedback-enabled"], c = [], o = !0, E = !1, _ = void 0;
        try {
          for (var y = f[Symbol.iterator](), L; !(o = (L = y.next()).done); o = !0) {
            var S = L.value;
            Object.getOwnPropertyDescriptor(u, S) !== void 0 && u[S] !== void 0 && u[S] !== n.params[S] && c.push(S);
          }
        } catch (P) {
          (E = !0, _ = P);
        } finally {
          try {
            !o && y.return != null && y.return();
          } finally {
            if (E) throw _;
          }
        }
        (c.length > 0 && b(("The parameters ").concat(f.join(","), " is/are not allowed be changed between the calls of render() and execute() of a widget.\n    Consider rendering a new widget if you want to change the following parameters ").concat(c.join(",")), 3618), u.action !== void 0 && u.action !== "" && (pr(u.action) || b(("Invalid input for optional parameter \"action\", got \"").concat(u.action, "\""), 3604), n.action = u.action), u.cData !== void 0 && u.cData !== "" && (vr(u.cData) || b(("Invalid input for optional parameter \"cData\", got \"").concat(u.cData, "\""), 3605), n.cData = u.cData), u["after-interactive-callback"] !== void 0 && (n.cbAfterInteractive = u["after-interactive-callback"]), u["before-interactive-callback"] !== void 0 && (n.cbBeforeInteractive = u["before-interactive-callback"]), u.callback !== void 0 && (n.cbSuccess = u.callback), u["expired-callback"] !== void 0 && (n.cbExpired = u["expired-callback"]), u["timeout-callback"] !== void 0 && (n.cbTimeout = u["timeout-callback"]), u["error-callback"] !== void 0 && (n.cbError = u["error-callback"]), u["unsupported-callback"] !== void 0 && (n.cbUnsupported = u["unsupported-callback"]), u.chlPageData !== void 0 && u.chlPageData !== "" && (n.chlPageData = u.chlPageData));
      }
    }, k = function (n, u, f) {
      (n === "explicit" && u !== void 0 && w(u, f), T($a(n)));
    }, H = function (n) {
      R(ee.Api, n, ye(Sn, m));
    }, R = function (n, u, f) {
      var c, o, E = M(u);
      E === null && b("Nothing to reset found for provided container", 3329);
      var _ = m.widgetMap.get(E);
      (_ === void 0 && b(("Widget ").concat(E, " to reset was not found."), 3331), st(_, f));
      var y = _.isExecuted;
      (_.isResetting = !0, _.response = void 0, _.mode = void 0, _.msgQueue = [], _.isComplete = !1, _.isExecuted = !1, _.isExecuting = !1, _.isExpired = !1, _.isFailed = !1, _.isInitialized = !1, _.isStale = !1, _.isOverrunning = !1, _.cfChlOut = void 0, _.cfChlOutS = void 0, _.errorCode = void 0, _.frMd = void 0, _.autoFeedbackSent = !1, _.watchcat.overrunBeginSeq = 0, _.watchcat.lastAckedSeq = 0, _.watchcat.seq = 0, r(_, n, y) && (_.msgQueue.push(it.Execute), _.isExecuted = !0, _.isExecuting = !0));
      var L = G(E), S = _.shadow.querySelector(("#").concat(L));
      (S === null && b(("Widget ").concat(E, " to reset was not found."), 3330), (_.params.appearance === _e.InteractionOnly || _.params.appearance === _e.Execute) && ia(S), _.params.sitekey === null && b("Unexpected Error: Sitekey is null", 3347));
      var P = S.cloneNode();
      A(P, HTMLIFrameElement) || b("Unexpected Error: Cloned widget is not an iframe", 3348);
      var q = tr(E, _.params.sitekey, _.params, (c = _.rcV) !== null && c !== void 0 ? c : me, !1, "b", n, m.scriptUrlParsed, Er(_));
      (P.src = q, aa(P, _), _.iframeOrigin = Je(q), (o = S.parentNode) === null || o === void 0 || o.replaceChild(P, S), Tr(_, L), _.retryTimeout !== void 0 && window.clearTimeout(_.retryTimeout));
    }, F = function (n, u) {
      var f = G(n), c = [("input#").concat(f, "_response"), ("input#").concat(f, "_g_response")];
      (document.querySelectorAll(c.join(", ")).forEach(function (o) {
        o.remove();
      }), u.shadow.querySelectorAll(c.join(", ")).forEach(function (o) {
        o.remove();
      }), vt(f), je(u), u.wrapper.remove(), u.retryTimeout !== void 0 && window.clearTimeout(u.retryTimeout), m.widgetMap.delete(n), mt(m));
    }, C = function (n) {
      var u = ye(In, m), f = M(n), c = f === null ? void 0 : m.widgetMap.get(f);
      if (f === null || c === void 0) {
        T("Nothing to remove found for the provided container.");
        return;
      }
      (dt(m.gcs, u), st(c, u), F(f, c));
    }, N = function () {
      var n = Ce(m.widgetMap.keys()), u = !0, f = !1, c = void 0;
      try {
        for (var o = n[Symbol.iterator](), E; !(u = (E = o.next()).done); u = !0) {
          var _ = E.value, y = m.widgetMap.get(_), L = G(_);
          y !== void 0 && (vt(L), je(y), R(ee.UpgradeReload, L));
        }
      } catch (S) {
        (f = !0, c = S);
      } finally {
        try {
          !u && o.return != null && o.return();
        } finally {
          if (f) throw c;
        }
      }
    }, I = function (n, u, f, c) {
      var o, E, _, y, L, S, P, q, ue, le, pe, Ee = X(), te, Q;
      if (typeof n == "string") {
        var ie = Ft(n);
        if (ie === null) {
          var ce;
          try {
            ce = document.querySelector(n);
          } catch (fi) {
            b(("Invalid type for \"container\", expected \"selector\" or an implementation of \"HTMLElement\", got \"").concat(n, "\""), 3586);
          }
          (ce === null && b(("Unable to find a container for \"").concat(n, "\""), 3585), te = ce);
        } else {
          var de, B = m.widgetMap.get(ie), ht = (de = B == null ? void 0 : B.wrapper.parentElement) !== null && de !== void 0 ? de : null;
          if (ht !== null && ra(f, B)) (te = ht, Q = {
            widget: B,
            widgetId: ie
          }); else return (B !== void 0 && Se(ie, B, c), k(f, B, u), G(ie));
        }
      } else A(n, HTMLElement) ? te = n : b("Invalid type for parameter \"container\", expected \"string\" or an implementation of \"HTMLElement\"", 3587);
      if (Q === void 0) {
        var Ie = Ft(te);
        if (Ie !== null) {
          var se = m.widgetMap.get(Ie);
          if (se !== void 0 && ra(f, se) && se.wrapper.parentElement === te) Q = {
            widget: se,
            widgetId: Ie
          }; else return (se && Se(Ie, se, c), k(f, se, u), G(Ie));
        }
      }
      var Pe = wr();
      if (Pe === void 0 || Pe === "") return b("Turnstile cannot determine its page location", 3607);
      var Xe = si(te);
      if (Xe !== void 0) {
        var h = Object.assign(Xe, u), Ae = h.action, Oe = h.cData, bt = h.chlPageData, xe = h.sitekey;
        (h.theme = (o = h.theme) !== null && o !== void 0 ? o : St.Auto, h.retry = (E = h.retry) !== null && E !== void 0 ? E : At.Auto, h.execution = (_ = h.execution) !== null && _ !== void 0 ? _ : at.Render, h.appearance = (y = h.appearance) !== null && y !== void 0 ? y : _e.Always, h["retry-interval"] = Zn(h["retry-interval"], Gr), h["expiry-interval"] = Zn(h["expiry-interval"], (cn - dn) * 1000), h.size = (L = h.size) !== null && L !== void 0 ? L : Z.Normal);
        var Et = h.callback, Gt = h["expired-callback"], Ye = h["timeout-callback"], Xt = h["after-interactive-callback"], xt = h["before-interactive-callback"], Qe = h["error-callback"], $e = h["unsupported-callback"];
        (typeof xe != "string" && b(("Invalid or missing type for parameter \"sitekey\", expected \"string\", got \"").concat(typeof xe == "undefined" ? "undefined" : D(xe), "\""), 3588), Gn(xe) || b(("Invalid input for parameter \"sitekey\", got \"").concat(xe, "\""), 3589), mr(h.size) || b(("Invalid type for parameter \"size\", expected normal|compact, got \"").concat(String(h.size), "\" ").concat(D(h.size)), 3590), cr(h.theme) || b(("Invalid type for parameter \"theme\", expected dark|light|auto, got \"").concat(String(h.theme), "\" ").concat(D(h.theme)), 3591), dr(h.retry) || b(("Invalid type for parameter \"retry\", expected never|auto, got \"").concat(String(h.retry), "\" ").concat(D(h.retry)), 3592), (h.language === void 0 || h.language === "") && (h.language = "auto"), yr(h.language) || (T(("Invalid language value: \"").concat(h.language, ", expected either: auto, or an ISO 639-1 two-letter language code (e.g. en) or language and country code (e.g. en-US).")), h.language = "auto"), hr(h.appearance) || b(("Unknown appearance value: \"").concat(String(h.appearance), ", expected either: 'always', 'execute', or 'interaction-only'."), 3600), br(h.execution) || b(("Unknown execution value: \"").concat(String(h.execution), ", expected either: 'render' or 'execute'."), 3601), sr(h["retry-interval"]) || b(("Invalid retry-interval value: \"").concat(h["retry-interval"], ", expected an integer value > 0 and < 900000\""), 3602), fr(h["expiry-interval"]) || b(("Invalid expiry-interval value: \"").concat(h["expiry-interval"], ", expected an integer value > 0 and < 360000\""), 3602));
        var Te = (S = h["refresh-expired"]) !== null && S !== void 0 ? S : Be.Auto;
        gr(Te) ? h["refresh-expired"] = Te : b(("Invalid type for parameter \"refresh-expired\", expected never|manual|auto, got \"").concat(String(Te), "\" ").concat(typeof Te == "undefined" ? "undefined" : D(Te)), 3603);
        var ve = (P = h["refresh-timeout"]) !== null && P !== void 0 ? P : nt.Auto;
        (_r(ve) ? h["refresh-timeout"] = ve : b(("Invalid type for parameter \"refresh-timeout\", expected never|manual|auto, got \"").concat(String(ve), "\" ").concat(typeof ve == "undefined" ? "undefined" : D(ve)), 3603), pr(Ae) || b(("Invalid input for optional parameter \"action\", got \"").concat(Ae, "\""), 3604), vr(Oe) || b(("Invalid input for optional parameter \"cData\", got \"").concat(Oe, "\""), 3605));
        var $ = document.createElement("iframe"), Ze = document.createElement("div"), Tt = Ze.attachShadow({
          mode: "closed"
        }), De = v(), re = G(De), Fe = [], et = h.execution === at.Render;
        et && Fe.push(it.Execute);
        var Ue = ze(m.gcs);
        (dt(Ue, c), m.lastWidgetIdx++);
        var He = {}, pa = Yt(ke({
          action: Ae,
          assetCtxCallback: h._acCb,
          autoFeedbackSent: !1,
          cData: Oe,
          cbAfterInteractive: Xt,
          cbBeforeInteractive: xt,
          cbError: Qe,
          cbExpired: Gt,
          cbSuccess: Et,
          cbTimeout: Ye,
          cbUnsupported: $e,
          chlPageData: bt,
          feedbackOpen: !1,
          gcs: Ue,
          idx: m.lastWidgetIdx,
          isComplete: !1,
          isExecuted: et,
          isExecuting: et,
          isExpired: !1,
          isFailed: !1,
          isInitialized: !1,
          isOverrunning: !1,
          isResetting: !1,
          isStale: !1,
          msgQueue: Fe,
          params: h,
          rcV: me,
          renderSource: f,
          responseElementsBuilt: !1,
          shadow: Tt,
          watchcat: {
            lastAckedSeq: 0,
            missingWidgetWarning: !1,
            overrunBeginSeq: 0,
            seq: 0
          }
        }, He), {
          widgetInitStartTimeTsMs: 0,
          widgetParamsStartTimeTsMs: 0,
          widgetRenderEndTimeTsMs: 0,
          widgetRenderStartTimeTsMs: Ee,
          wrapper: Ze
        });
        (m.widgetMap.set(De, pa), or(m));
        var we = m.widgetMap.get(De);
        (we === void 0 && b("Turnstile Initialization Error ", 3606), we.chlPageData !== void 0 && we.chlPageData !== "" && Ir(), $.style.display = "none", $.style.border = "none", $.style.overflow = "hidden");
        var Cr = tr(De, xe, h, me, !1, "b", ee.New, m.scriptUrlParsed, Er(we));
        (we.iframeOrigin = Je(Cr), $.setAttribute("src", Cr), aa($, we));
        var Mr = ["cross-origin-isolated", "fullscreen", "autoplay", "keyboard-map", "gamepad", "xr-spatial-tracking"];
        return (K((q = (pe = document.featurePolicy) === null || pe === void 0 || (le = pe.features) === null || le === void 0 ? void 0 : le.call(pe)) !== null && q !== void 0 ? q : [], Qt) && Mr.push(Qt), $.setAttribute("allow", Mr.join("; ")), $.setAttribute("sandbox", "allow-same-origin allow-scripts allow-popups"), $.id = re, $.tabIndex = (ue = h.tabindex) !== null && ue !== void 0 ? ue : 0, $.title = "Widget containing a Cloudflare security challenge", Tt.appendChild($), ca(we, re), Q && F(Q.widgetId, Q.widget), te.appendChild(Ze), we.widgetRenderEndTimeTsMs = X(), re);
      }
    }, be = function (n, u) {
      return I(n, u, "explicit", ye(wn, m));
    }, oe = function () {
      var n = [qr, Br];
      m.isRecaptchaCompatibilityMode && n.push(Jr);
      var u = ye(Cn, m);
      document.querySelectorAll(n.join(", ")).forEach(function (f) {
        I(f, void 0, "implicit", u);
      });
    }, W = function () {
      var n, u = -1, f = !0, c = !1, o = void 0;
      try {
        for (var E = m.widgetMap[Symbol.iterator](), _; !(f = (_ = E.next()).done); f = !0) {
          var y = Ve(_.value, 2), L = y[0], S = y[1];
          u < S.idx && (n = L, u = S.idx);
        }
      } catch (P) {
        (c = !0, o = P);
      } finally {
        try {
          !f && E.return != null && E.return();
        } finally {
          if (c) throw o;
        }
      }
      return (u === -1 && b("Could not find widget", 43778), n);
    }, O = ci(), V = function (n) {
      var u = Reflect.get(n, "source");
      if (u === J) {
        var f = Reflect.get(n, "widgetId");
        if (!(typeof f != "string" || f === "" || !m.widgetMap.has(f))) {
          var c = G(f), o = m.widgetMap.get(f);
          if (o !== void 0) switch (n.event) {
            case "init":
              {
                (o.widgetInitStartTimeTsMs = X(), o.kills = n.kills, Lt(o) && (o.gcs.length = 0));
                var E = o.shadow.querySelector(("#").concat(c));
                (A(E, HTMLElement) || b(("Cannot initialize Widget, Element not found (#").concat(c, ")."), 3074), o.mode = n.mode, o.nextRcV = n.nextRcV, o.mode === ge.Invisible && o.params["refresh-expired"] === Be.Manual && T(("refresh-expired=manual is impossible in invisible mode, consider using '").concat(Be.Auto, "' or '").concat(Be.Never, ".'")), o.mode !== ge.Managed && o.params["refresh-timeout"] !== nt.Auto && T("setting refresh-timeout has no effect on an invisible/non-interactive widget and will be ignored."), o.params.appearance === _e.Always || o.isExecuting && o.params.appearance === _e.Execute ? Ut(E, o) : ia(E), E.style.display = "");
                var _ = Ne(o, c);
                (_ || b(("Received state for an unknown widget: ").concat(n.widgetId), 3078), ne(_, {
                  event: "init",
                  source: J,
                  widgetId: n.widgetId
                }, o.iframeOrigin));
                break;
              }
            case "translationInit":
              {
                var y = o.shadow.querySelector(("#").concat(c));
                A(y, HTMLElement) || b(("Cannot initialize Widget, Element not found (#").concat(c, ")."), 3074);
                var L = new Map();
                (o.displayLanguage = n.displayLanguage, o.displayRtl = n.displayRtl, Object.keys(n.translationData).forEach(function (He) {
                  L.set(He, n.translationData[He]);
                }), ri(y, L));
                break;
              }
            case "languageUnsupported":
              {
                (T(("Language ").concat(o.params.language, " is not supported, falling back to: ").concat(n.fallback, ".")), o.displayLanguage = n.fallback);
                break;
              }
            case "reject":
              {
                var S = o.shadow.querySelector(("#").concat(c));
                (o.isExecuting = !1, A(S, HTMLElement) || b(("Cannot initialize Widget, Element not found (#").concat(c, ")."), 3075));
                var P = Reflect.get(n, "reason");
                if (P === "unsupported_browser") {
                  var q;
                  (q = o.cbUnsupported) === null || q === void 0 || q.call(o);
                }
                break;
              }
            case "food":
              {
                n.seq > o.watchcat.lastAckedSeq && (o.watchcat.lastAckedSeq = n.seq);
                break;
              }
            case "overrunBegin":
              {
                (o.isOverrunning = !0, o.watchcat.overrunBeginSeq = o.watchcat.lastAckedSeq);
                break;
              }
            case "overrunEnd":
              {
                o.isOverrunning = !1;
                break;
              }
            case "complete":
              {
                if ((d(o, me, n.widgetId), o.response = n.token, n.aC !== void 0 && n.aC !== "")) {
                  var ue;
                  (ue = o.assetCtxCallback) === null || ue === void 0 || ue.call(o, n.aC);
                }
                if (n.scs !== void 0 && n.scs !== "" && !Ge("scs", o) && (o.scs = n.scs, o.params["session-continuity-persist"] === !0 && !Ge("scs_persist", o))) {
                  var le = o.params.sitekey;
                  if (le !== null && le !== "") {
                    var pe = ("").concat($t).concat(le);
                    try {
                      localStorage.setItem(pe, n.scs);
                    } catch (He) {}
                  }
                }
                n.sToken !== void 0 && n.sToken !== "" ? e(o, n.widgetId, c, n.token, n.sToken, n.chlId) : i(o, c, !1);
                break;
              }
            case "fail":
              {
                var Ee = Reflect.get(n, "rcV");
                if ((typeof Ee == "string" && Ee !== "" && d(o, Ee, f), n.cfChlOut !== void 0 && n.cfChlOut !== "" && (o.cfChlOut = n.cfChlOut), n.cfChlOutS !== void 0 && n.cfChlOutS !== "" && (o.cfChlOutS = n.cfChlOutS), n.code !== void 0 && n.code !== 0 && (o.errorCode = n.code), n.aC !== void 0 && n.aC !== "")) {
                  var te;
                  (te = o.assetCtxCallback) === null || te === void 0 || te.call(o, n.aC);
                }
                (o.isExecuting = !1, o.isFailed = !0, o.isInitialized = !0, n.frMd !== void 0 && n.frMd !== "" && (o.frMd = n.frMd), Tr(o, c));
                var Q = o.cbError, ie = n.code === Ot || n.code === kt, ce = n.code !== sn;
                if (ie) {
                  var de = Ne(o, c);
                  de && ne(de, {
                    event: "forceFail",
                    source: J,
                    widgetId: n.widgetId
                  }, o.iframeOrigin);
                }
                if (Q !== void 0) {
                  var B;
                  Q(String((B = n.code) !== null && B !== void 0 ? B : pn)) === !0 ? ce && o.params.retry === At.Auto && !o.isResetting && t(o, c, ie) : (n.code !== void 0 && n.code !== 0 && T(("Error: ").concat(n.code, ".")), ce && t(o, c, ie));
                } else n.code !== void 0 && n.code !== 0 ? (ce && t(o, c, ie), b(("Error: ").concat(n.code), 3076)) : t(o, c, !1);
                break;
              }
            case "feedbackInit":
              {
                var ht = jt(o, c).targetWindow;
                if (ht) {
                  T("A feedback report form is already opened for this widget.");
                  return;
                }
                if (o.autoFeedbackSent !== !0 && !Ge("feedback-report-auto-submit", o)) {
                  var Ie = Fn(o, n.feedbackOrigin, n.rayId, o.frMd, m.scriptUrlParsed);
                  Ie && (o.autoFeedbackSent = !0);
                }
                if ((o.feedbackOpen = !0, o.retryTimeout !== void 0)) {
                  var se, Pe;
                  (clearTimeout(o.retryTimeout), o.retryTimeout = void 0, (Pe = (se = o).pendingRetry) !== null && Pe !== void 0 || (se.pendingRetry = {
                    crashed: !1
                  }));
                }
                (Un(), window.postMessage({
                  event: "feedbackOpen",
                  source: J,
                  widgetId: n.widgetId
                }, "*"), ir(c, o, n.feedbackOrigin, m.scriptUrlParsed, function () {
                  a(o, c, n.widgetId);
                }));
                break;
              }
            case "requestFeedbackData":
              {
                var Xe = Ne(o, c);
                (A(Xe, HTMLElement) || b(("Received state for an unknown widget: #").concat(c, " / ").concat(n.widgetId), 3078), ne(Xe, {
                  event: "requestTurnstileResults",
                  source: J,
                  widgetId: n.widgetId
                }, o.iframeOrigin));
                break;
              }
            case "turnstileResults":
              {
                var h, Ae, Oe, bt = jt(o, c), xe = bt.targetOrigin, Et = bt.targetWindow;
                if (!Et) break;
                er(Et, {
                  cfChlOut: (h = o.cfChlOut) !== null && h !== void 0 ? h : n.cfChlOut,
                  cfChlOutS: (Ae = o.cfChlOutS) !== null && Ae !== void 0 ? Ae : n.cfChlOutS,
                  errorCode: o.errorCode,
                  event: "feedbackData",
                  frMd: (Oe = o.frMd) !== null && Oe !== void 0 ? Oe : n.frMd,
                  mode: n.mode,
                  rayId: n.rayId,
                  rcV: n.rcV,
                  sitekey: n.sitekey,
                  source: J,
                  widgetId: n.widgetId
                }, xe);
                break;
              }
            case "closeFeedbackReportIframe":
              {
                var Gt = jt(o, c).targetWindow;
                (Gt || b(("Received state for an unknown widget: ").concat(n.widgetId), 3078), vt(("").concat(c, "-fr")), je(o), a(o, c, n.widgetId));
                break;
              }
            case "tokenExpired":
              {
                var Ye, Xt = n.token;
                (o.isExpired = !0, (Ye = o.cbExpired) === null || Ye === void 0 || Ye.call(o, Xt), o.params["refresh-expired"] === Be.Auto && !o.isResetting && R(ee.AutoExpire, c));
                break;
              }
            case "interactiveTimeout":
              {
                (d(o, me, n.widgetId), Tr(o, c));
                var xt = o.cbTimeout;
                if ((xt ? xt() : o.params["refresh-timeout"] === nt.Never && !o.isResetting && T("The widget encountered an interactive timeout and is set to never refresh. Consider defining a timeout handler and resetting the widget upon timeout as solving a widget in a timed-out state is going to fail."), o.params["refresh-timeout"] === nt.Auto && !o.isResetting)) {
                  var Qe = o.cbAfterInteractive;
                  (Qe == null || Qe(), R(ee.AutoTimeout, c));
                }
                break;
              }
            case "refreshRequest":
              {
                (d(o, me, n.widgetId), vt(c), je(o), R(ee.ManualRefresh, c));
                break;
              }
            case "reloadRequest":
              {
                (d(o, n.nextRcV, n.widgetId), R(Xa(n.trigger) ? n.trigger : ee.Api, c));
                break;
              }
            case "reloadApiJsRequest":
              {
                if (Ge("reload", o)) {
                  _t(n.widgetId);
                  break;
                }
                if (Kt !== void 0) {
                  _t(n.widgetId);
                  break;
                }
                if (Za()) {
                  _t(n.widgetId);
                  break;
                }
                fa() ? (m.apiJsMismatchReloadAttempts++, ei(), ti(n.widgetId)) : _t(n.widgetId);
                break;
              }
            case "interactiveBegin":
              {
                var $e, Te = o.shadow.querySelector(("#").concat(c));
                (A(Te, HTMLElement) || b(("Cannot layout widget, Element not found (#").concat(c, ")."), 3076), ($e = o.cbBeforeInteractive) === null || $e === void 0 || $e.call(o), o.params.appearance === _e.InteractionOnly && Ut(Te, o));
                break;
              }
            case "interactiveEnd":
              {
                var ve;
                (ve = o.cbAfterInteractive) === null || ve === void 0 || ve.call(o);
                break;
              }
            case "widgetStale":
              {
                o.isStale = !0;
                break;
              }
            case "requestExtraParams":
              {
                o.widgetParamsStartTimeTsMs = X();
                var $ = Ne(o, c);
                ($ || b(("Received state for an unknown widget: ").concat(n.widgetId), 3078), o.isResetting = !1);
                var Ze = {}, Tt = X(), De = {
                  "d.cT": s(),
                  "ht.atrs": l(document.body.parentElement),
                  "pg.ref": document.referrer,
                  pi: {
                    ffp: rn(o.wrapper),
                    ii: window.self !== window.top,
                    lH: window.location.href,
                    mL: document.querySelectorAll("meta").length,
                    pfp: un(document, Yr, Qr, xr),
                    sL: document.scripts.length,
                    sR: o.wrapper.shadowRoot === null,
                    ssL: Ga(document, xr),
                    t: ("").concat(document.title.length, "|").concat(ln(document.title)),
                    tL: on(document, xr),
                    wp: tn(o.wrapper),
                    xp: en(o.wrapper).slice(0, $r)
                  },
                  "w.iW": window.innerWidth
                }, re = o.scs;
                if ((re === void 0 || re === "") && o.params["session-continuity-persist"] === !0 && !Ge("scs_persist", o)) {
                  var Fe = o.params.sitekey;
                  if (Fe !== null && Fe !== "") {
                    var et = ("").concat($t).concat(Fe);
                    try {
                      var Ue;
                      re = (Ue = localStorage.getItem(et)) !== null && Ue !== void 0 ? Ue : void 0;
                    } catch (He) {}
                  }
                }
                (re !== void 0 && re !== "" && re.length > Zr && (re = void 0), ne($, ke({
                  action: o.action,
                  apiJsMismatchReloadAttempts: m.apiJsMismatchReloadAttempts,
                  apiJsMismatchReloadCompletedCount: m.apiJsMismatchReloadCompletedCount,
                  apiJsResourceTiming: O === void 0 ? void 0 : Ya(O),
                  appearance: o.params.appearance,
                  au: m.scriptUrl,
                  cData: o.cData,
                  ch: "80a697ecdece",
                  chlPageData: o.chlPageData,
                  cs: ft(o),
                  event: "extraParams",
                  execution: o.params.execution,
                  "expiry-interval": o.params["expiry-interval"],
                  language: o.params.language,
                  rcV: o.rcV,
                  "refresh-expired": o.params["refresh-expired"],
                  "refresh-timeout": o.params["refresh-timeout"],
                  retry: o.params.retry,
                  "retry-interval": o.params["retry-interval"],
                  scs: re,
                  source: J,
                  timeExtraParamsMs: X() - o.widgetRenderStartTimeTsMs,
                  timeInitMs: o.widgetInitStartTimeTsMs - o.widgetRenderEndTimeTsMs,
                  timeLoadInitMs: X() - m.turnstileLoadInitTimeTsMs,
                  timeParamsMs: o.widgetParamsStartTimeTsMs - o.widgetInitStartTimeTsMs,
                  timeRenderMs: o.widgetRenderEndTimeTsMs - o.widgetRenderStartTimeTsMs,
                  timeTiefMs: X() - Tt,
                  upgradeAttempts: m.upgradeAttempts,
                  upgradeCompletedCount: m.upgradeCompletedCount,
                  url: wr(),
                  wPr: De,
                  widgetId: n.widgetId
                }, Ze), o.iframeOrigin), p(o, n.widgetId, $), o.isInitialized = !0);
                break;
              }
            default:
              break;
          }
        }
      }
    }, z = function (n) {
      if (oi(n)) {
        var u = n.data;
        if (!ui(n)) {
          T(("Ignored message from wrong origin: ").concat(n.origin, "."));
          return;
        }
        if (!(u.widgetId === "" || !m.widgetMap.has(u.widgetId))) {
          var f = G(u.widgetId), c = m.widgetMap.get(u.widgetId);
          if (c !== void 0) {
            if (!li(n, c, f)) {
              T(("Ignored message from unexpected source for event: ").concat(u.event, "."));
              return;
            }
            V(u);
          }
        }
      }
    };
    (m.msgHandler = z, m.internalMsgHandler = V, window.addEventListener("message", z));
    function M(x) {
      var n;
      if (typeof x == "string") {
        var u = Ft(x);
        if (u !== null) return u;
        try {
          var f = document.querySelector(x);
          return f === null ? null : M(f);
        } catch (o) {
          return null;
        }
      }
      if (A(x, Element)) return Ft(x);
      var c = !!x;
      return c || m.widgetMap.size === 0 ? null : (n = W()) !== null && n !== void 0 ? n : null;
    }
    var Y = {}, ae = {
      showFeedback: function (n) {
        var u = M(n);
        if (u !== null) {
          var f = G(u), c = m.widgetMap.get(u);
          c !== void 0 && ir(f, c, vn.Custom, m.scriptUrlParsed);
        }
      }
    }, j = Yt(ke({}, Y), {
      _private: ae,
      execute: function (n, u) {
        var f = ye(Rn, m), c = !1, o = M(n);
        if (o === null) {
          var E;
          u === void 0 && b("Please provide 2 parameters to execute: container and parameters", 43521);
          var _ = I(n, u, "explicit", f);
          (c = !0, _ == null && b("Failed to render widget", 43522), o = (E = lt(_)) !== null && E !== void 0 ? E : M(n), o === null && b("Failed to render widget", 43522));
        }
        var y = m.widgetMap.get(o);
        if (y !== void 0) {
          var L = c ? !1 : st(y, f);
          w(y, u);
          var S = G(o);
          if (y.isExecuting) {
            (T(("Call to execute() on a widget that is already executing (").concat(S, "), consider using reset() before execute().")), L && Nt(o, y));
            return;
          }
          if ((y.isExecuting = !0, y.response !== void 0 && y.response !== "")) {
            var P;
            (y.isExecuting = !1, T(("Call to execute() on a widget that was already executed (").concat(S, "), execute() will return the previous token obtained. Consider using reset() before execute() to obtain a fresh token.")), L && Nt(o, y), (P = y.cbSuccess) === null || P === void 0 || P.call(y, y.response, !1));
            return;
          }
          (y.isExpired && T(("Call to execute on a expired-widget (").concat(S, "), consider using reset() before.")), y.isStale && (R(ee.StaleExecute, S), y.isExecuting = !0), (y.isResetting || !y.isInitialized) && y.msgQueue.push(it.Execute), y.isExecuted = !0);
          var q = Ne(y, S);
          if ((q || (y.isExecuting = !1, b(("Widget ").concat(S, " to execute was not found"), 43522)), y.isResetting || !y.isInitialized)) return;
          if (y.msgQueue.length > 0) {
            (p(y, o, q), y.params.appearance === _e.Execute && Ut(q, y));
            return;
          }
          (y.params.appearance === _e.Execute && Ut(q, y), g(y) && ne(q, {
            cs: ft(y),
            event: "execute",
            source: J,
            widgetId: o
          }, y.iframeOrigin));
        }
      },
      getResponse: function (n) {
        var u = ye(An, m);
        if (typeof n == "undefined") {
          var f = W();
          if (f !== void 0) {
            var c = m.widgetMap.get(f);
            return (c !== void 0 && Se(f, c, u), (c == null ? void 0 : c.isExpired) === !0 && T("Call to getResponse on a widget that expired, consider refreshing the widget."), c == null ? void 0 : c.response);
          }
          b("Could not find a widget", 43794);
        }
        var o = M(n);
        o === null && b("Could not find widget for provided container", 43778);
        var E = m.widgetMap.get(o);
        return (E && Se(o, E, u), E == null ? void 0 : E.response);
      },
      isExpired: function (n) {
        var u, f = ye(On, m);
        if (typeof n == "undefined") {
          var c = W();
          if (c !== void 0) {
            var o, E = m.widgetMap.get(c);
            return (E !== void 0 && Se(c, E, f), (o = E == null ? void 0 : E.isExpired) !== null && o !== void 0 ? o : !1);
          }
          b("Could not find a widget", 43794);
        }
        var _ = M(n);
        _ === null && b("Could not find widget for provided container", 43778);
        var y = m.widgetMap.get(_);
        return (y && Se(_, y, f), (u = y == null ? void 0 : y.isExpired) !== null && u !== void 0 ? u : !1);
      },
      ready: function (n) {
        (m.scriptWasLoadedAsync && (T("turnstile.ready() would break if called *before* the Turnstile api.js script is loaded by visitors."), b("Remove async/defer from the Turnstile api.js script tag before using turnstile.ready().", 3857)), typeof n != "function" && b(("turnstile.ready() expected a \"function\" argument, got \"").concat(typeof n == "undefined" ? "undefined" : D(n), "\""), 3841));
        var u = ye(kn, m);
        dt(m.gcs, u);
        var f = !0, c = !1, o = void 0;
        try {
          for (var E = m.widgetMap[Symbol.iterator](), _; !(f = (_ = E.next()).done); f = !0) {
            var y = Ve(_.value, 2), L = y[0], S = y[1];
            Se(L, S, u);
          }
        } catch (P) {
          (c = !0, o = P);
        } finally {
          try {
            !f && E.return != null && E.return();
          } finally {
            if (c) throw o;
          }
        }
        if (m.isReady) {
          n();
          return;
        }
        kr.push(n);
      },
      remove: C,
      render: be,
      reset: H
    });
    return (Object.defineProperty(j, oa, {
      configurable: !0,
      enumerable: !1,
      value: {
        clearPendingApiJsReloadRequest: function () {
          Ar();
        },
        rearmTimedUpgrade: function () {
          Or();
        },
        rejectPendingApiJsReloadRequest: function () {
          la();
        },
        reloadAfterUpgrade: function () {
          N();
        }
      }
    }), {
      runImplicitRender: oe,
      turnstile: j
    });
  })(), di = function () {
    sa.runImplicitRender();
  }, Wt = sa.turnstile;
  function si(e) {
    var t, r, a = e.getAttribute("data-sitekey"), i = {
      sitekey: a
    }, l = e.getAttribute("data-tabindex");
    l !== null && l !== "" && (i.tabindex = Number.parseInt(l, 10));
    var s = e.getAttribute("data-theme");
    s !== null && s !== "" && (cr(s) ? i.theme = s : T(("Unknown data-theme value: \"").concat(s, "\".")));
    var d = e.getAttribute("data-size");
    if ((d !== null && d !== "" && (mr(d) ? i.size = d : T(("Unknown data-size value: \"").concat(d, "\"."))), 0)) var v;
    var p = e.getAttribute("data-action");
    typeof p == "string" && (i.action = p);
    var g = e.getAttribute("data-cdata");
    typeof g == "string" && (i.cData = g);
    var w = e.getAttribute("data-retry");
    w !== null && w !== "" && (dr(w) ? i.retry = w : T(("Invalid data-retry value: \"").concat(w, ", expected either 'never' or 'auto'\".")));
    var k = e.getAttribute("data-retry-interval");
    if (k !== null && k !== "") {
      var H = Number.parseInt(k, 10);
      sr(H) ? i["retry-interval"] = H : T(("Invalid data-retry-interval value: \"").concat(k, ", expected an integer value > 0 and < 900000\"."));
    }
    var R = e.getAttribute("data-expiry-interval");
    if (R !== null && R !== "") {
      var F = Number.parseInt(R, 10);
      fr(F) ? i["expiry-interval"] = F : T(("Invalid data-expiry-interval value: \"").concat(F, ", expected an integer value > 0 and < 360000\"."));
    }
    var C = e.getAttribute("data-refresh-expired");
    C !== null && C !== "" && (gr(C) ? i["refresh-expired"] = C : T(("Unknown data-refresh-expired value: \"").concat(C, ", expected either: 'never', 'auto' or 'manual'.")));
    var N = e.getAttribute("data-refresh-timeout");
    N !== null && N !== "" && (_r(N) ? i["refresh-timeout"] = N : T(("Unknown data-refresh-timeout value: \"").concat(N, ", expected either: 'never', 'auto' or 'manual'.")));
    var I = e.getAttribute("data-language");
    I !== null && I !== "" && (yr(I) ? i.language = I : T(("Invalid data-language value: \"").concat(I, ", expected either: auto, or an ISO 639-1 two-letter language code (e.g. en) or language and country code (e.g. en-US).")));
    function be(j) {
      var x = e.getAttribute(j);
      if (!(x === null || x === "")) {
        var n = Sr(x);
        return n === void 0 ? void 0 : function () {
          for (var u = arguments.length, f = new Array(u), c = 0; c < u; c++) f[c] = arguments[c];
          return n.apply(void 0, Ce(f));
        };
      }
    }
    var oe = ["error-callback", "unsupported-callback", "callback", "expired-callback", "timeout-callback", "after-interactive-callback", "before-interactive-callback"];
    (oe.forEach(function (j) {
      Object.assign(i, We({}, j, be(("data-").concat(j))));
    }), i["feedback-enabled"] = (t = Ht(e.getAttribute("data-feedback-enabled"), !0, function (j) {
      return ("Invalid data-feedback-enabled value: \"").concat(j, "\", expected either: 'true' or 'false'. Value is ignored.");
    })) !== null && t !== void 0 ? t : !0, i["response-field"] = (r = Ht(e.getAttribute("data-response-field"), !0, function (j) {
      return ("Invalid data-response-field value: \"").concat(j, "\", expected either: 'true' or 'false'. Value is ignored.");
    })) !== null && r !== void 0 ? r : !0);
    var W = e.getAttribute("data-response-field-name");
    W !== null && W !== "" && (i["response-field-name"] = W);
    var O = e.getAttribute("data-execution");
    O !== null && O !== "" && (br(O) ? i.execution = O : T(("Unknown data-execution value: \"").concat(O, ", expected either: 'render' or 'execute'.")));
    var V = e.getAttribute("data-appearance");
    V !== null && V !== "" && (hr(V) ? i.appearance = V : T(("Unknown data-appearance value: \"").concat(V, ", expected either: 'always', 'execute', or 'interaction-only'.")));
    var z = e.getAttribute("data-offlabel-show-privacy"), M = Ht(z, void 0, function (j) {
      return ("Invalid data-offlabel-show-privacy value: \"").concat(j, "\", expected \"true\" or \"false\".");
    });
    typeof M == "boolean" && (i["offlabel-show-privacy"] = M);
    var Y = e.getAttribute("data-offlabel-show-help"), ae = Ht(Y, void 0, function (j) {
      return ("Invalid data-offlabel-show-help value: \"").concat(j, "\", expected \"true\" or \"false\".");
    });
    return (typeof ae == "boolean" && (i["offlabel-show-help"] = ae), i);
  }
  function fa() {
    if ((Ir(), ua())) return !1;
    var e = jn(window.turnstile, m);
    return e ? !0 : (Or(), !1);
  }
  (Le = !1, U = xn(), m.scriptWasLoadedAsync = (Vt = U == null ? void 0 : U.loadedAsync) !== null && Vt !== void 0 ? Vt : !1, m.scriptUrl = (qt = U == null ? void 0 : U.src) !== null && qt !== void 0 ? qt : "undefined", m.scriptUrlParsed = U == null ? void 0 : U.url, (U == null ? void 0 : U.params) !== void 0 && U.params !== null && (Ke = U.params.get("compat"), (Ke == null ? void 0 : Ke.toLowerCase()) === "recaptcha" ? typeof window.grecaptcha == "undefined" ? (T("Compatibility layer enabled."), m.isRecaptchaCompatibilityMode = !0, window.grecaptcha = Wt) : T("grecaptcha is already defined. The compatibility layer will not be enabled.") : Ke !== null && T(("Unknown%20value%20for%20api.js").concat(Ke, "\", ignoring.")), U.params.forEach(function (e, t) {
    K(["onload", "compat", "_cb", "_upgrade", "_reload", "render"], t) || T(("Unknown parameter passed to api.js: \"?").concat(t, "=...\", ignoring."));
  }), Le = U.params.get("_upgrade") === "true", he = U.params.get("onload"), he !== null && he !== "" && !Le && setTimeout(function () {
    var e = Sr(he);
    e === void 0 ? (T(("Unable to find onload callback '").concat(he, "' immediately after loading, expected 'function', got '").concat(D(Rr(he)), "'.")), setTimeout(function () {
      var t = Sr(he);
      t === void 0 ? T(("Unable to find onload callback '").concat(he, "' after 1 second, expected 'function', got '").concat(D(Rr(he)), "'.")) : t();
    }, 1000)) : e();
  }, 0)), gt = ("turnstile" in window), fe = gt ? ta(window.turnstile) : void 0, Bt = gt && Le ? Kn(window.turnstile, m, function () {
    var e;
    (window.turnstile = Wt, (e = ta(Wt)) === null || e === void 0 || e.reloadAfterUpgrade(), or(m));
  }) : !1, Bt && (fe == null || fe.clearPendingApiJsReloadRequest()), gt && Le && !Bt ? (T("Turnstile upgrade state was missing. Keeping the existing Turnstile instance."), fe == null || fe.rejectPendingApiJsReloadRequest(), fe == null || fe.rearmTimedUpgrade()) : gt && !Le ? T("Turnstile already has been loaded. Was Turnstile imported multiple times?") : (Bt || (window.turnstile = Wt), Le || ((U == null || (Jt = U.params) === null || Jt === void 0 ? void 0 : Jt.get("render")) !== "explicit" && kr.push(di), document.readyState === "complete" || document.readyState === "interactive" ? setTimeout(na, 0) : window.addEventListener("DOMContentLoaded", na)), Or()));
  var Vt, qt, Le, U, Ke, he, gt, fe, Bt, Jt;
})();
